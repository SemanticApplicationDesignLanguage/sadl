/************************************************************************
 * Copyright © 2022 - Natural Semantics, LLC. All Rights Reserved.
 *
 * Project: com.naturalsemantics.sadl.builtin.increment
 *
 * Description: The Semantic Application Design Language (SADL) is a
 * language for building semantic models and expressing rules that
 * capture additional domain knowledge. The SADL-IDE (integrated
 * development environment) is a set of Eclipse plug-ins that
 * support the editing and testing of semantic models using the
 * SADL language.
 *
 * This software is distributed "AS-IS" without ANY WARRANTIES
 * and licensed under the Eclipse Public License - v 1.0
 * which is available at http://www.eclipse.org/org/documents/epl-v10.php
 *
 ***********************************************************************/

package com.naturalsemantics.sadl.builtin.increment;

/**
 * This class implements a method that increments its integer input by 2 and returns
 * the result. It is provided as part of an Eclipse plug-in project, along with a 
 * feature and an update project, as a demonstration of how to provide Java classes
 * and methods as implementations of SADL External equations.
 * 
 * @author Natural Semantics, LLC
 *
 */
public class Increment {

	public int increment(int i) {
		return i+2;
	}
}
