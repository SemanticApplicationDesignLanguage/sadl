% custom predicates should be defined here

strConcat(S1,S2,S3,S4,S5,S6,R) :- strConcat(S1,S2,S3,s4,S5,R1), string_concat(R1,S6,R).
strConcat(S1,S2,S3,S4,S5,R) :- strConcat(S1,S2,S3,s4,R1), string_concat(R1,S5,R).
strConcat(S1,S2,S3,S4,R) :- strConcat(S1,S2,S3,R1), string_concat(R1,S4,R).
strConcat(S1,S2,S3,R) :- strConcat(S1,S2,R1), string_concat(R1,S3,R).
strConcat(S1,S2,R) :- string_concat(S1,S2,R).

print(S1,S2,S3,S4,S5,S6) :- strConcat(S1,S2,S3,S4,S5,S6,R), print(R).
print(S1,S2,S3,S4,S5) :- strConcat(S1,S2,S3,S4,S5,R), print(R).
print(S1,S2,S3,S4) :- strConcat(S1,S2,S3,S4,R), print(R).
print(S1,S2,S3) :- strConcat(S1,S2,S3,R), print(R).
print(S1,S2) :- strConcat(S1,S2,R), print(R).
