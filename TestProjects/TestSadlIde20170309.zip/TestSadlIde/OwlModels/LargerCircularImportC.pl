:- rdf_load('LargerCircularImportD.owl').
:- consult('LargerCircularImportD.pl').
