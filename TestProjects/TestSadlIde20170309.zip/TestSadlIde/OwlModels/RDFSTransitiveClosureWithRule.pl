holds('http://sadl.imp/RDFSTransitiveClosureWithRule#ruleFired', PVx, true) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/RDFSTransitiveClosureWithRule#Thingy').
