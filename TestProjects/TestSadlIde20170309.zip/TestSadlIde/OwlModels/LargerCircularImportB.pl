:- rdf_load('LargerCircularImportC.owl').
:- consult('LargerCircularImportC.pl').
