:- rdf_load('shapes-specific.owl').
:- consult('shapes-specific.pl').
holds('http://sadl.imp/shapes_top#area', PVx, PVv2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/shapes_specific#Circle'), holds('http://sadl.imp/shapes_specific#radius', PVx, literal(type(PV12,PV13))), atom_number(PV13,PVv0), PVv1 is PVv0 ** 2, PVv2 is PVv1 * 3.14159.
holds('http://sadl.imp/shapes_top#area', PVx, PVv2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/shapes_specific#Rectangle'), holds('http://sadl.imp/shapes_specific#height', PVx, literal(type(PV14,PV15))), atom_number(PV15,PVv0), holds('http://sadl.imp/shapes_specific#width', PVx, literal(type(PV16,PV17))), atom_number(PV17,PVv1), PVv2 is PVv0 * PVv1.
print(PVx, ' has area ', PVy) :- holds('http://sadl.imp/shapes_top#area', PVx, literal(type(PV18,PV19))), atom_number(PV19,PVy).
