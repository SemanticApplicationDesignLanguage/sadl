:- rdf_load('FamilyRelationships.owl').
:- consult('FamilyRelationships.pl').
