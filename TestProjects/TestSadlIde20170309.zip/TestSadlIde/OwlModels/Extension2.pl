:- rdf_load('Extended.owl').
:- consult('Extended.pl').
