:- rdf_load('CrossModelRestrictionPart1.owl').
:- consult('CrossModelRestrictionPart1.pl').
