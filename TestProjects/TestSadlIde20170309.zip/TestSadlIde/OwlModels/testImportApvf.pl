:- rdf_load('aulo.owl').
:- consult('aulo.pl').
