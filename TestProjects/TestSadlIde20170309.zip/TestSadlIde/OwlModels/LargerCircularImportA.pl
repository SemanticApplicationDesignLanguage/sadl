:- rdf_load('LargerCircularImportB.owl').
:- consult('LargerCircularImportB.pl').
