:- rdf_load('DuplicateImportPrefixLevel2.owl').
:- consult('DuplicateImportPrefixLevel2.pl').
holds('http://www.w3.org/2000/01/rdf-schema#comment', PVx, 'You are an A!') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/DuplicateImportPrefixLevel3#A').
