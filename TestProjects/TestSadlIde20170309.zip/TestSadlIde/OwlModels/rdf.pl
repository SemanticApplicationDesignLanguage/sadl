rdf('http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#DatatypeProperty','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#Property','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#Property','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#Property','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Property').
rdf('63ac135f:152eb74f179:-72b8(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b8(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b8(blank node)').
rdf('63ac135f:152eb74f179:-72b8(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72b8(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72b8(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#imports','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#OntologyProperty').
rdf('http://www.w3.org/2002/07/owl#imports','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Ontology').
rdf('http://www.w3.org/2002/07/owl#imports','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2002/07/owl#Ontology').
rdf('http://www.w3.org/2001/XMLSchema#negativeInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2002/07/owl#ObjectProperty','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#intersectionOf','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#comment','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#backwardCompatibleWith','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Ontology').
rdf('http://www.w3.org/2002/07/owl#backwardCompatibleWith','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2002/07/owl#Ontology').
rdf('http://www.w3.org/2002/07/owl#Ontology','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#Ontology','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#Ontology','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Ontology').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#first','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#first','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/1999/02/22-rdf-syntax-ns#List').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#first','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#FunctionalProperty').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#description','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#onProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#onProperty','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Restriction').
rdf('http://www.w3.org/2002/07/owl#onProperty','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2002/07/owl#Property').
rdf('http://www.w3.org/2002/07/owl#differentFrom','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#SymmetricProperty').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#object','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#object','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/1999/02/22-rdf-syntax-ns#Statement').
rdf('http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#SymmetricProperty').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Alt','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Container').
rdf('http://www.w3.org/2002/07/owl#Class','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#Class','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#Class','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#Class','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#List','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#List','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#List','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#List').
rdf('63ac135f:152eb74f179:-72b7(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b7(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b7(blank node)').
rdf('63ac135f:152eb74f179:-72b7(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72b7(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72b7(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Statement','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Statement','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Statement','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#Statement').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Seq','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Container').
rdf('http://www.w3.org/2001/XMLSchema#double','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#double','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#double').
rdf('http://www.w3.org/2001/XMLSchema#double','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#double','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2001/XMLSchema#gMonth','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2002/07/owl#FunctionalProperty','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2002/07/owl#SymmetricProperty','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#ObjectProperty').
rdf('http://www.w3.org/2001/XMLSchema#gMonthDay','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2002/07/owl#maxCardinality','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2000/01/rdf-schema#ContainerMembershipProperty','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Property','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Property','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Property','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2002/07/owl#sameAs','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#SymmetricProperty').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2001/XMLSchema#gDay','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#nil','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#List').
rdf('http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2000/01/rdf-schema#isDefinedBy','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#seeAlso').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2002/07/owl#Nothing','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#Nothing','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('http://www.w3.org/2002/07/owl#Nothing','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#Nothing','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#Nothing','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Nothing').
rdf('http://www.w3.org/2002/07/owl#Nothing','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2002/07/owl#Nothing').
rdf('http://www.w3.org/2002/07/owl#InverseFunctionalProperty','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#ObjectProperty').
rdf('http://www.w3.org/2001/XMLSchema#hexBinary','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2002/07/owl#oneOf','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Class').
rdf('63ac135f:152eb74f179:-72b6(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b6(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b6(blank node)').
rdf('63ac135f:152eb74f179:-72b6(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72b6(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72b6(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Thing').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Bag','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Container').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#decimal').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#predicate','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#predicate','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/1999/02/22-rdf-syntax-ns#Statement').
rdf('http://www.w3.org/2001/XMLSchema#gYear','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2002/07/owl#Thing','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#Thing','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('http://www.w3.org/2002/07/owl#Thing','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#Thing','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Person','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Person','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Person','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Person','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72b5(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b5(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b5(blank node)').
rdf('63ac135f:152eb74f179:-72b5(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72b5(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72b5(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#incompatibleWith','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Ontology').
rdf('http://www.w3.org/2002/07/owl#incompatibleWith','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2002/07/owl#Ontology').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Thing').
rdf('http://www.w3.org/2002/07/owl#OntologyProperty','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#priorVersion','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Ontology').
rdf('http://www.w3.org/2002/07/owl#priorVersion','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2002/07/owl#Ontology').
rdf('http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2000/01/rdf-schema#Resource','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#Resource','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Location','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Location','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Location','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://com.ge.research.sadlGeorgeAndMartha#Location').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Location','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72bb(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72bb(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72bb(blank node)').
rdf('63ac135f:152eb74f179:-72bb(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72bb(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72bb(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#rest','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#rest','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/1999/02/22-rdf-syntax-ns#List').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#rest','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/1999/02/22-rdf-syntax-ns#List').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#rest','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#FunctionalProperty').
rdf('http://www.w3.org/2002/07/owl#TransitiveProperty','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#ObjectProperty').
rdf('http://www.w3.org/2002/07/owl#onClass','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2001/XMLSchema#positiveInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://com.ge.research.sadlGeorgeAndMartha#Birth').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2000/01/rdf-schema#Class','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#Class','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#Class','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72b4(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b4(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b4(blank node)').
rdf('63ac135f:152eb74f179:-72b4(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72b4(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72b4(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#versionInfo','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#AnnotationProperty').
rdf('http://www.w3.org/2000/01/rdf-schema#Datatype','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#anyURI','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2001/XMLSchema#base64Binary','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('63ac135f:152eb74f179:-72ba(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72ba(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72ba(blank node)').
rdf('63ac135f:152eb74f179:-72ba(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72ba(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72ba(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2002/07/owl#maxQualifiedCardinality','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('63ac135f:152eb74f179:-72b9(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b9(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b9(blank node)').
rdf('63ac135f:152eb74f179:-72b9(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72b9(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72b9(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#subject','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#subject','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/1999/02/22-rdf-syntax-ns#Statement').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#decimal').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2000/01/rdf-schema#Literal','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#Literal','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#Literal','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Literal').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('63ac135f:152eb74f179:-72b3(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b3(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b3(blank node)').
rdf('63ac135f:152eb74f179:-72b3(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72b3(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72b3(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#Restriction','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#Restriction','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#Restriction','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#Restriction','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2002/07/owl#Restriction').
rdf('http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2001/XMLSchema#gYearMonth','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Datatype').
rdf('63ac135f:152eb74f179:-72b8(blank node)','http://www.w3.org/2002/07/owl#onProperty','http://com.ge.research.sadlGeorgeAndMartha#weight').
rdf('63ac135f:152eb74f179:-72b8(blank node)','http://www.w3.org/2002/07/owl#maxCardinality','1').
rdf('63ac135f:152eb74f179:-72b8(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Restriction').
rdf('63ac135f:152eb74f179:-72b2(blank node)','http://com.ge.research.sadlGeorgeAndMartha#child','http://com.ge.research.sadlGeorgeAndMartha#Samuel').
rdf('63ac135f:152eb74f179:-72b2(blank node)','http://com.ge.research.sadlGeorgeAndMartha#mother','http://com.ge.research.sadlGeorgeAndMartha#Mary').
rdf('63ac135f:152eb74f179:-72b2(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Birth').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/2000/01/rdf-schema#range','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/2000/01/rdf-schema#domain','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#ObjectProperty').
rdf('http://com.ge.research.sadlGeorgeAndMartha#description','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2001/XMLSchema#string').
rdf('http://com.ge.research.sadlGeorgeAndMartha#description','http://www.w3.org/2000/01/rdf-schema#domain','http://com.ge.research.sadlGeorgeAndMartha#Location').
rdf('http://com.ge.research.sadlGeorgeAndMartha#description','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#DatatypeProperty').
rdf('http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2001/XMLSchema#double').
rdf('http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/2000/01/rdf-schema#domain','http://com.ge.research.sadlGeorgeAndMartha#Location').
rdf('http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#DatatypeProperty').
rdf('63ac135f:152eb74f179:-72b7(blank node)','http://www.w3.org/2002/07/owl#onProperty','http://com.ge.research.sadlGeorgeAndMartha#when').
rdf('63ac135f:152eb74f179:-72b7(blank node)','http://www.w3.org/2002/07/owl#maxCardinality','1').
rdf('63ac135f:152eb74f179:-72b7(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Restriction').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://com.ge.research.sadlGeorgeAndMartha#child','http://com.ge.research.sadlGeorgeAndMartha#George').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://com.ge.research.sadlGeorgeAndMartha#mother','http://com.ge.research.sadlGeorgeAndMartha#Mary').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://com.ge.research.sadlGeorgeAndMartha#location','63ac135f:152eb74f179:-72b0(blank node)').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://com.ge.research.sadlGeorgeAndMartha#when','Fri Feb 22 00:00:00 EST 1732').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://com.ge.research.sadlGeorgeAndMartha#weight','9.45').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Birth').
rdf('http://com.ge.research.sadlGeorgeAndMartha#George','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Ruby','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Mary','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('63ac135f:152eb74f179:-72b6(blank node)','http://www.w3.org/2002/07/owl#onProperty','http://com.ge.research.sadlGeorgeAndMartha#location').
rdf('63ac135f:152eb74f179:-72b6(blank node)','http://www.w3.org/2002/07/owl#maxQualifiedCardinality','1').
rdf('63ac135f:152eb74f179:-72b6(blank node)','http://www.w3.org/2002/07/owl#onClass','http://com.ge.research.sadlGeorgeAndMartha#Location').
rdf('63ac135f:152eb74f179:-72b6(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Restriction').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#range','http://com.ge.research.sadlGeorgeAndMartha#Location').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#domain','http://com.ge.research.sadlGeorgeAndMartha#Birth').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#ObjectProperty').
rdf('63ac135f:152eb74f179:-72af(blank node)','http://com.ge.research.sadlGeorgeAndMartha#child','http://com.ge.research.sadlGeorgeAndMartha#Ruby').
rdf('63ac135f:152eb74f179:-72af(blank node)','http://com.ge.research.sadlGeorgeAndMartha#weight','9.45').
rdf('63ac135f:152eb74f179:-72af(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Birth').
rdf('http://com.ge.research.sadlGeorgeAndMartha#NewYorkNY','http://com.ge.research.sadlGeorgeAndMartha#latitude','40.7141667').
rdf('http://com.ge.research.sadlGeorgeAndMartha#NewYorkNY','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Location').
rdf('63ac135f:152eb74f179:-72b0(blank node)','http://com.ge.research.sadlGeorgeAndMartha#latitude','38.186111').
rdf('63ac135f:152eb74f179:-72b0(blank node)','http://com.ge.research.sadlGeorgeAndMartha#longitude','-76.930556').
rdf('63ac135f:152eb74f179:-72b0(blank node)','http://com.ge.research.sadlGeorgeAndMartha#description','Popes Creek Estate near present-day Colonial Beach, Virginia, USA').
rdf('63ac135f:152eb74f179:-72b0(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Location').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Martha','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Person','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Person','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Person','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('63ac135f:152eb74f179:-72b5(blank node)','http://www.w3.org/2002/07/owl#onProperty','http://com.ge.research.sadlGeorgeAndMartha#mother').
rdf('63ac135f:152eb74f179:-72b5(blank node)','http://www.w3.org/2002/07/owl#maxQualifiedCardinality','1').
rdf('63ac135f:152eb74f179:-72b5(blank node)','http://www.w3.org/2002/07/owl#onClass','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('63ac135f:152eb74f179:-72b5(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Restriction').
rdf('63ac135f:152eb74f179:-72ae(blank node)','http://com.ge.research.sadlGeorgeAndMartha#child','63ac135f:152eb74f179:-72ad(blank node)').
rdf('63ac135f:152eb74f179:-72ae(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Birth').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#range','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#domain','http://com.ge.research.sadlGeorgeAndMartha#Birth').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#ObjectProperty').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Location','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72ba(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Location','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72bb(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Location','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('63ac135f:152eb74f179:-72bb(blank node)','http://www.w3.org/2002/07/owl#onProperty','http://com.ge.research.sadlGeorgeAndMartha#longitude').
rdf('63ac135f:152eb74f179:-72bb(blank node)','http://www.w3.org/2002/07/owl#maxCardinality','1').
rdf('63ac135f:152eb74f179:-72bb(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Restriction').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b5(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b6(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b7(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b8(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b9(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Philadelphia','http://com.ge.research.sadlGeorgeAndMartha#latitude','39.9522').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Philadelphia','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Location').
rdf('63ac135f:152eb74f179:-72b4(blank node)','http://www.w3.org/2002/07/owl#onProperty','http://com.ge.research.sadlGeorgeAndMartha#age').
rdf('63ac135f:152eb74f179:-72b4(blank node)','http://www.w3.org/2002/07/owl#maxCardinality','1').
rdf('63ac135f:152eb74f179:-72b4(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Restriction').
rdf('63ac135f:152eb74f179:-72ad(blank node)','http://com.ge.research.sadlGeorgeAndMartha#friend','63ac135f:152eb74f179:-72ac(blank node)').
rdf('63ac135f:152eb74f179:-72ad(blank node)','http://com.ge.research.sadlGeorgeAndMartha#age','24').
rdf('63ac135f:152eb74f179:-72ad(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#range','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#domain','http://com.ge.research.sadlGeorgeAndMartha#Birth').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#ObjectProperty').
rdf('http://com.ge.research.sadlGeorgeAndMartha','http://www.w3.org/2000/01/rdf-schema#comment','This ontology was created from a SADL file GeorgeAndMartha.sadl and should not be edited.').
rdf('http://com.ge.research.sadlGeorgeAndMartha','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Ontology').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/2000/01/rdf-schema#domain','http://com.ge.research.sadlGeorgeAndMartha#Birth').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#DatatypeProperty').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/2000/01/rdf-schema#range','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/2000/01/rdf-schema#domain','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#ObjectProperty').
rdf('http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2001/XMLSchema#double').
rdf('http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/2000/01/rdf-schema#domain','http://com.ge.research.sadlGeorgeAndMartha#Location').
rdf('http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#DatatypeProperty').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2001/XMLSchema#float').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/2000/01/rdf-schema#domain','http://com.ge.research.sadlGeorgeAndMartha#Birth').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#DatatypeProperty').
rdf('63ac135f:152eb74f179:-72ba(blank node)','http://www.w3.org/2002/07/owl#onProperty','http://com.ge.research.sadlGeorgeAndMartha#latitude').
rdf('63ac135f:152eb74f179:-72ba(blank node)','http://www.w3.org/2002/07/owl#maxCardinality','1').
rdf('63ac135f:152eb74f179:-72ba(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Restriction').
rdf('63ac135f:152eb74f179:-72b9(blank node)','http://www.w3.org/2002/07/owl#onProperty','http://com.ge.research.sadlGeorgeAndMartha#weight').
rdf('63ac135f:152eb74f179:-72b9(blank node)','http://www.w3.org/2002/07/owl#maxCardinality','1').
rdf('63ac135f:152eb74f179:-72b9(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Restriction').
rdf('http://com.ge.research.sadlGeorgeAndMartha#likes','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2001/XMLSchema#string').
rdf('http://com.ge.research.sadlGeorgeAndMartha#likes','http://www.w3.org/2000/01/rdf-schema#domain','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#likes','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#DatatypeProperty').
rdf('63ac135f:152eb74f179:-72b3(blank node)','http://www.w3.org/2002/07/owl#onProperty','http://com.ge.research.sadlGeorgeAndMartha#spouse').
rdf('63ac135f:152eb74f179:-72b3(blank node)','http://www.w3.org/2002/07/owl#maxQualifiedCardinality','1').
rdf('63ac135f:152eb74f179:-72b3(blank node)','http://www.w3.org/2002/07/owl#onClass','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('63ac135f:152eb74f179:-72b3(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Restriction').
rdf('63ac135f:152eb74f179:-72ac(blank node)','http://com.ge.research.sadlGeorgeAndMartha#friend','http://com.ge.research.sadlGeorgeAndMartha#Mary').
rdf('63ac135f:152eb74f179:-72ac(blank node)','http://com.ge.research.sadlGeorgeAndMartha#age','23').
rdf('63ac135f:152eb74f179:-72ac(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Samuel','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2001/XMLSchema#decimal').
rdf('http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/2000/01/rdf-schema#domain','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#DatatypeProperty').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#unsignedLong').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#unsignedLong').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#unsignedInt').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#unsignedLong').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#unsignedInt').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#byte').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#short').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#unsignedByte').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#unsignedShort').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#unsignedLong').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#unsignedInt').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#short').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#unsignedShort').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#byte').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#short').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2001/XMLSchema#short').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#byte').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedShort').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedLong').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedInt').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#short').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedByte').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#decimal').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonPositiveInteger').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#byte').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedShort').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedLong').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedInt').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#short').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedByte').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#decimal').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonPositiveInteger').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#byte').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedShort').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedLong').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedInt').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#short').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedByte').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#decimal').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonPositiveInteger').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#byte').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedShort').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedLong').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedInt').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#short').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedByte').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#decimal').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonPositiveInteger').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#byte').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedShort').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedLong').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedInt').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#short').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedByte').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#decimal').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonPositiveInteger').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#byte').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedShort').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedLong').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedInt').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#short').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedByte').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#decimal').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonPositiveInteger').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#byte').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedShort').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedLong').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedInt').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#short').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#unsignedByte').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#decimal').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#nonPositiveInteger').
rdf('http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#time').
rdf('http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#string').
rdf('http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#duration').
rdf('http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#date').
rdf('http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2001/XMLSchema#boolean').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Mary','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72ac(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72ad(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72b2(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Ruby','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#George','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Samuel','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72ae(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72af(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72b0(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72b8(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b9(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Philadelphia','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72ba(blank node)').
rdf('63ac135f:152eb74f179:-72b0(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72ba(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#NewYorkNY','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72ba(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Philadelphia','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b0(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#NewYorkNY','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Philadelphia','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#NewYorkNY','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Philadelphia','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72bb(blank node)').
rdf('63ac135f:152eb74f179:-72b0(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72bb(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#NewYorkNY','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72bb(blank node)').
rdf('63ac135f:152eb74f179:-72ae(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72af(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b2(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72ae(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b9(blank node)').
rdf('63ac135f:152eb74f179:-72af(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b9(blank node)').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b9(blank node)').
rdf('63ac135f:152eb74f179:-72b2(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b9(blank node)').
rdf('63ac135f:152eb74f179:-72ae(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b7(blank node)').
rdf('63ac135f:152eb74f179:-72af(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b7(blank node)').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b7(blank node)').
rdf('63ac135f:152eb74f179:-72b2(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b7(blank node)').
rdf('63ac135f:152eb74f179:-72ae(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b8(blank node)').
rdf('63ac135f:152eb74f179:-72af(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b8(blank node)').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b8(blank node)').
rdf('63ac135f:152eb74f179:-72b2(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b8(blank node)').
rdf('63ac135f:152eb74f179:-72ae(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b5(blank node)').
rdf('63ac135f:152eb74f179:-72af(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b5(blank node)').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b5(blank node)').
rdf('63ac135f:152eb74f179:-72b2(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b5(blank node)').
rdf('63ac135f:152eb74f179:-72ae(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b6(blank node)').
rdf('63ac135f:152eb74f179:-72af(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b6(blank node)').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b6(blank node)').
rdf('63ac135f:152eb74f179:-72b2(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b6(blank node)').
rdf('63ac135f:152eb74f179:-72b9(blank node)','http://www.w3.org/2000/01/rdf-schema#subClassOf','63ac135f:152eb74f179:-72b8(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Ruby','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#George','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b4(blank node)').
rdf('63ac135f:152eb74f179:-72ac(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Samuel','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b4(blank node)').
rdf('63ac135f:152eb74f179:-72ad(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Martha','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Mary','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Ruby','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#George','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72ac(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Samuel','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72ad(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Martha','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Mary','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Martha','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Ruby','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#George','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b3(blank node)').
rdf('63ac135f:152eb74f179:-72ac(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Samuel','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b3(blank node)').
rdf('63ac135f:152eb74f179:-72ad(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Martha','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Mary','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://www.w3.org/2000/01/rdf-schema#Datatype','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#SymmetricProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#OntologyProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#FunctionalProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#AnnotationProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#ObjectProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#DatatypeProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#incompatibleWith','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#imports','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#priorVersion','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#intersectionOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#backwardCompatibleWith','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#oneOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://com.ge.research.sadlGeorgeAndMartha#likes','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Property','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#List','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#Nothing','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b8(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#Resource','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#Ontology','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Person','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#Property','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b7(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b4(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72bb(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72ba(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#Class','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b5(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#Restriction','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#Thing','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b6(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#Class','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Statement','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b9(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b3(blank node)','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Location','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#Literal','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#double','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#Datatype','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#SymmetricProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#OntologyProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#FunctionalProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#AnnotationProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#ObjectProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#DatatypeProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#nil','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#gYear','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#gDay','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#gMonth','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#anyURI','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#gYearMonth','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#negativeInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#gMonthDay','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#base64Binary','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#positiveInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#hexBinary','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#gYear','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#gDay','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#gMonth','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#anyURI','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#gYearMonth','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#negativeInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#gMonthDay','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#base64Binary','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#XMLLiteral','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#positiveInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#hexBinary','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#sameAs','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#differentFrom','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2002/07/owl#sameAs','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#ObjectProperty').
rdf('http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#ObjectProperty').
rdf('http://www.w3.org/2002/07/owl#differentFrom','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#ObjectProperty').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Ruby','http://www.w3.org/2002/07/owl#sameAs','http://com.ge.research.sadlGeorgeAndMartha#Ruby').
rdf('http://com.ge.research.sadlGeorgeAndMartha#George','http://www.w3.org/2002/07/owl#sameAs','http://com.ge.research.sadlGeorgeAndMartha#George').
rdf('63ac135f:152eb74f179:-72ac(blank node)','http://www.w3.org/2002/07/owl#sameAs','63ac135f:152eb74f179:-72ac(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Samuel','http://www.w3.org/2002/07/owl#sameAs','http://com.ge.research.sadlGeorgeAndMartha#Samuel').
rdf('63ac135f:152eb74f179:-72ad(blank node)','http://www.w3.org/2002/07/owl#sameAs','63ac135f:152eb74f179:-72ad(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Martha','http://www.w3.org/2002/07/owl#sameAs','http://com.ge.research.sadlGeorgeAndMartha#Martha').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Mary','http://www.w3.org/2002/07/owl#sameAs','http://com.ge.research.sadlGeorgeAndMartha#Mary').
rdf('63ac135f:152eb74f179:-72ae(blank node)','http://www.w3.org/2002/07/owl#sameAs','63ac135f:152eb74f179:-72ae(blank node)').
rdf('63ac135f:152eb74f179:-72af(blank node)','http://www.w3.org/2002/07/owl#sameAs','63ac135f:152eb74f179:-72af(blank node)').
rdf('63ac135f:152eb74f179:-72b1(blank node)','http://www.w3.org/2002/07/owl#sameAs','63ac135f:152eb74f179:-72b1(blank node)').
rdf('63ac135f:152eb74f179:-72b2(blank node)','http://www.w3.org/2002/07/owl#sameAs','63ac135f:152eb74f179:-72b2(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Philadelphia','http://www.w3.org/2002/07/owl#sameAs','http://com.ge.research.sadlGeorgeAndMartha#Philadelphia').
rdf('63ac135f:152eb74f179:-72b0(blank node)','http://www.w3.org/2002/07/owl#sameAs','63ac135f:152eb74f179:-72b0(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#NewYorkNY','http://www.w3.org/2002/07/owl#sameAs','http://com.ge.research.sadlGeorgeAndMartha#NewYorkNY').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#isDefinedBy','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2000/01/rdf-schema#seeAlso','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2000/01/rdf-schema#Container','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Property','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#List','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#Restriction','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#Literal','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#double','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Statement','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#Class','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#Resource','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#Property','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#Class','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#Ontology','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2002/07/owl#TransitiveProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Bag','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#InverseFunctionalProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Seq','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Alt','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2000/01/rdf-schema#ContainerMembershipProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#TransitiveProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Bag','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#InverseFunctionalProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Seq','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Alt','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#ContainerMembershipProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#Ontology','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2002/07/owl#Ontology').
rdf('http://www.w3.org/2002/07/owl#Thing','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2002/07/owl#Thing').
rdf('63ac135f:152eb74f179:-72b9(blank node)','http://www.w3.org/2002/07/owl#equivalentClass','63ac135f:152eb74f179:-72b9(blank node)').
rdf('63ac135f:152eb74f179:-72bb(blank node)','http://www.w3.org/2002/07/owl#equivalentClass','63ac135f:152eb74f179:-72bb(blank node)').
rdf('http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#dateTime').
rdf('http://www.w3.org/2000/01/rdf-schema#Class','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('63ac135f:152eb74f179:-72b8(blank node)','http://www.w3.org/2002/07/owl#equivalentClass','63ac135f:152eb74f179:-72b8(blank node)').
rdf('http://www.w3.org/2002/07/owl#Property','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2002/07/owl#Property').
rdf('http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#decimal').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Location','http://www.w3.org/2002/07/owl#equivalentClass','http://com.ge.research.sadlGeorgeAndMartha#Location').
rdf('http://www.w3.org/2000/01/rdf-schema#Resource','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('63ac135f:152eb74f179:-72b5(blank node)','http://www.w3.org/2002/07/owl#equivalentClass','63ac135f:152eb74f179:-72b5(blank node)').
rdf('http://www.w3.org/2002/07/owl#Class','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2002/07/owl#Class').
rdf('http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#float').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Statement','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/1999/02/22-rdf-syntax-ns#Statement').
rdf('63ac135f:152eb74f179:-72b4(blank node)','http://www.w3.org/2002/07/owl#equivalentClass','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/2002/07/owl#equivalentClass','http://com.ge.research.sadlGeorgeAndMartha#Birth').
rdf('http://www.w3.org/2001/XMLSchema#double','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#double').
rdf('63ac135f:152eb74f179:-72b3(blank node)','http://www.w3.org/2002/07/owl#equivalentClass','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://www.w3.org/2000/01/rdf-schema#Literal','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2000/01/rdf-schema#Literal').
rdf('http://www.w3.org/2002/07/owl#Restriction','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2002/07/owl#Restriction').
rdf('http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#string').
rdf('63ac135f:152eb74f179:-72b6(blank node)','http://www.w3.org/2002/07/owl#equivalentClass','63ac135f:152eb74f179:-72b6(blank node)').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#List','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/1999/02/22-rdf-syntax-ns#List').
rdf('http://com.ge.research.sadlGeorgeAndMartha#Person','http://www.w3.org/2002/07/owl#equivalentClass','http://com.ge.research.sadlGeorgeAndMartha#Person').
rdf('63ac135f:152eb74f179:-72ba(blank node)','http://www.w3.org/2002/07/owl#equivalentClass','63ac135f:152eb74f179:-72ba(blank node)').
rdf('63ac135f:152eb74f179:-72b7(blank node)','http://www.w3.org/2002/07/owl#equivalentClass','63ac135f:152eb74f179:-72b7(blank node)').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#Property','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/1999/02/22-rdf-syntax-ns#Property').
rdf('http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#unsignedLong').
rdf('http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#unsignedInt').
rdf('http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#unsignedByte').
rdf('http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
rdf('http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#unsignedShort').
rdf('http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#int').
rdf('http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#integer').
rdf('http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#long').
rdf('http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#byte').
rdf('http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2001/XMLSchema#short').
rdf('63ac135f:152eb74f179:-72b9(blank node)','http://www.w3.org/2002/07/owl#equivalentClass','63ac135f:152eb74f179:-72b8(blank node)').
rdf('63ac135f:152eb74f179:-72b8(blank node)','http://www.w3.org/2002/07/owl#equivalentClass','63ac135f:152eb74f179:-72b9(blank node)').
rdf('http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#range','63ac135f:152eb74f179:-72bb(blank node)').
rdf('http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#priorVersion','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#incompatibleWith','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#backwardCompatibleWith','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#imports','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#description','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#likes','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#rest','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#onProperty','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#range','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/2000/01/rdf-schema#range','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#range','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/2000/01/rdf-schema#range','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#range','63ac135f:152eb74f179:-72ba(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#range','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/2000/01/rdf-schema#range','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#range','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/2000/01/rdf-schema#range','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://www.w3.org/2000/01/rdf-schema#Container','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b9(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b9(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b9(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b9(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b9(blank node)').
rdf('http://www.w3.org/2002/07/owl#intersectionOf','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#oneOf','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#onProperty','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#description','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#description','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b7(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b7(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b7(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b7(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b7(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#likes','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Thing').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#onProperty','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2002/07/owl#Class').
rdf('http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#likes','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#description','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72bb(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72bb(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72bb(blank node)').
rdf('http://www.w3.org/2002/07/owl#intersectionOf','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#oneOf','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://www.w3.org/2002/07/owl#onProperty','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Class').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b8(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b8(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b8(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b8(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b8(blank node)').
rdf('http://www.w3.org/2002/07/owl#priorVersion','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#incompatibleWith','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#backwardCompatibleWith','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#imports','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#subject','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#predicate','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#object','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#rest','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#first','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b5(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b5(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b5(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b5(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b5(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#likes','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b4(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#description','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72ba(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72ba(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72ba(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#likes','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b3(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b6(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b6(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b6(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b6(blank node)').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#domain','63ac135f:152eb74f179:-72b6(blank node)').
rdf('http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#rest','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#first','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#object','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#subject','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#maxQualifiedCardinality','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#onProperty','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#predicate','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#comment','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#onClass','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#description','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#maxCardinality','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#imports','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#likes','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#sameAs','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#differentFrom','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#seeAlso','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#backwardCompatibleWith','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#incompatibleWith','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#priorVersion','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#intersectionOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2002/07/owl#oneOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://www.w3.org/2000/01/rdf-schema#isDefinedBy','http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#Resource').
rdf('http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://com.ge.research.sadlGeorgeAndMartha#longitude').
rdf('http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://com.ge.research.sadlGeorgeAndMartha#mother').
rdf('http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#subPropertyOf').
rdf('http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://com.ge.research.sadlGeorgeAndMartha#location').
rdf('http://www.w3.org/2002/07/owl#equivalentClass','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#equivalentClass').
rdf('http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://com.ge.research.sadlGeorgeAndMartha#weight').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#rest','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#rest').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#first','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#first').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#object','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#object').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#subject','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#subject').
rdf('http://www.w3.org/2002/07/owl#maxQualifiedCardinality','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#maxQualifiedCardinality').
rdf('http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#range').
rdf('http://www.w3.org/2000/01/rdf-schema#subClassOf','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#subClassOf').
rdf('http://www.w3.org/2002/07/owl#onProperty','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#onProperty').
rdf('http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://com.ge.research.sadlGeorgeAndMartha#child').
rdf('http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://com.ge.research.sadlGeorgeAndMartha#latitude').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#predicate','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#predicate').
rdf('http://www.w3.org/2000/01/rdf-schema#comment','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#comment').
rdf('http://www.w3.org/2002/07/owl#onClass','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#onClass').
rdf('http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://com.ge.research.sadlGeorgeAndMartha#when').
rdf('http://com.ge.research.sadlGeorgeAndMartha#description','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://com.ge.research.sadlGeorgeAndMartha#description').
rdf('http://www.w3.org/2002/07/owl#maxCardinality','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#maxCardinality').
rdf('http://www.w3.org/1999/02/22-rdf-syntax-ns#type','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/1999/02/22-rdf-syntax-ns#type').
rdf('http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#domain').
rdf('http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://com.ge.research.sadlGeorgeAndMartha#friend').
rdf('http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://com.ge.research.sadlGeorgeAndMartha#age').
rdf('http://www.w3.org/2002/07/owl#imports','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#imports').
rdf('http://com.ge.research.sadlGeorgeAndMartha#likes','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://com.ge.research.sadlGeorgeAndMartha#likes').
rdf('http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://com.ge.research.sadlGeorgeAndMartha#spouse').
rdf('http://www.w3.org/2002/07/owl#sameAs','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#sameAs').
rdf('http://www.w3.org/2002/07/owl#disjointWith','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#disjointWith').
rdf('http://www.w3.org/2002/07/owl#differentFrom','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#differentFrom').
rdf('http://www.w3.org/2000/01/rdf-schema#seeAlso','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#seeAlso').
rdf('http://www.w3.org/2002/07/owl#backwardCompatibleWith','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#backwardCompatibleWith').
rdf('http://www.w3.org/2002/07/owl#incompatibleWith','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#incompatibleWith').
rdf('http://www.w3.org/2002/07/owl#priorVersion','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#priorVersion').
rdf('http://www.w3.org/2002/07/owl#intersectionOf','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#intersectionOf').
rdf('http://www.w3.org/2002/07/owl#oneOf','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2002/07/owl#oneOf').
rdf('http://www.w3.org/2000/01/rdf-schema#isDefinedBy','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#isDefinedBy').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#double','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gMonth','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#Class','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gYearMonth','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#Resource','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#Literal','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Location','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gMonthDay','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Person','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gDay','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#negativeInteger','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#double','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#positiveInteger','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#hexBinary','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#base64Binary','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#anyURI','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gYear','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2000/01/rdf-schema#Datatype').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Ruby','http://com.ge.research.sadlGeorgeAndMartha#Person').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#George','http://com.ge.research.sadlGeorgeAndMartha#Person').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Philadelphia','http://com.ge.research.sadlGeorgeAndMartha#Location').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Samuel','http://com.ge.research.sadlGeorgeAndMartha#Person').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#NewYorkNY','http://com.ge.research.sadlGeorgeAndMartha#Location').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Martha','http://com.ge.research.sadlGeorgeAndMartha#Person').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Mary','http://com.ge.research.sadlGeorgeAndMartha#Person').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#Datatype','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Ruby','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#George','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Samuel','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Martha','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Mary','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Philadelphia','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#NewYorkNY','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#Resource','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Person','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#Class','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Location','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#Literal','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#double','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#Datatype','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gYear','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gDay','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gMonth','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#anyURI','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gYearMonth','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#negativeInteger','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gMonthDay','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#base64Binary','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#positiveInteger','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#hexBinary','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#time','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#date','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gYear','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gDay','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gMonth','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#anyURI','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gYearMonth','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#nonPositiveInteger','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#negativeInteger','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#gMonthDay','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#duration','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#base64Binary','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#boolean','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#positiveInteger','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#hexBinary','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#spouse','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#age','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#mother','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#location','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#when','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#weight','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#latitude','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#longitude','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#Container','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#Container','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#ContainerMembershipProperty','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#ContainerMembershipProperty','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#subPropertyOf','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#range','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#child','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#comment','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#description','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#domain','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#friend','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://com.ge.research.sadlGeorgeAndMartha#likes','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#seeAlso','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_instanceOf_','http://www.w3.org/2000/01/rdf-schema#isDefinedBy','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_subClassOf_','http://com.ge.research.sadlGeorgeAndMartha#Location','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_subClassOf_','http://www.w3.org/2000/01/rdf-schema#Datatype','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2001/XMLSchema#dateTime').
holds('_subClassOf_','http://www.w3.org/2000/01/rdf-schema#Class','http://www.w3.org/2000/01/rdf-schema#Class').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_subClassOf_','http://www.w3.org/2000/01/rdf-schema#Literal','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_subClassOf_','http://com.ge.research.sadlGeorgeAndMartha#Birth','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#dateTime','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2001/XMLSchema#decimal').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2001/XMLSchema#decimal').
holds('_subClassOf_','http://com.ge.research.sadlGeorgeAndMartha#Location','http://com.ge.research.sadlGeorgeAndMartha#Location').
holds('_subClassOf_','http://www.w3.org/2000/01/rdf-schema#Resource','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#decimal','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#float','http://www.w3.org/2001/XMLSchema#float').
holds('_subClassOf_','http://com.ge.research.sadlGeorgeAndMartha#Birth','http://com.ge.research.sadlGeorgeAndMartha#Birth').
holds('_subClassOf_','http://com.ge.research.sadlGeorgeAndMartha#Person','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#double','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#double','http://www.w3.org/2001/XMLSchema#double').
holds('_subClassOf_','http://www.w3.org/2000/01/rdf-schema#Literal','http://www.w3.org/2000/01/rdf-schema#Literal').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#string','http://www.w3.org/2001/XMLSchema#string').
holds('_subClassOf_','http://www.w3.org/2000/01/rdf-schema#Class','http://www.w3.org/2000/01/rdf-schema#Resource').
holds('_subClassOf_','http://com.ge.research.sadlGeorgeAndMartha#Person','http://com.ge.research.sadlGeorgeAndMartha#Person').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2001/XMLSchema#unsignedLong').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2001/XMLSchema#integer').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2001/XMLSchema#long').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedLong','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2001/XMLSchema#unsignedLong').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2001/XMLSchema#unsignedInt').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2001/XMLSchema#int').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2001/XMLSchema#integer').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2001/XMLSchema#long').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedInt','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2001/XMLSchema#unsignedLong').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2001/XMLSchema#unsignedInt').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2001/XMLSchema#int').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2001/XMLSchema#integer').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2001/XMLSchema#long').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2001/XMLSchema#byte').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2001/XMLSchema#short').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2001/XMLSchema#unsignedByte').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedByte','http://www.w3.org/2001/XMLSchema#unsignedShort').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2001/XMLSchema#integer').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#nonNegativeInteger','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2001/XMLSchema#unsignedLong').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2001/XMLSchema#unsignedInt').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2001/XMLSchema#int').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2001/XMLSchema#integer').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2001/XMLSchema#long').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2001/XMLSchema#short').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2001/XMLSchema#nonNegativeInteger').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#unsignedShort','http://www.w3.org/2001/XMLSchema#unsignedShort').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2001/XMLSchema#int').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2001/XMLSchema#integer').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#int','http://www.w3.org/2001/XMLSchema#long').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#integer','http://www.w3.org/2001/XMLSchema#integer').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2001/XMLSchema#integer').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#long','http://www.w3.org/2001/XMLSchema#long').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2001/XMLSchema#int').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2001/XMLSchema#integer').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2001/XMLSchema#long').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2001/XMLSchema#byte').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#byte','http://www.w3.org/2001/XMLSchema#short').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2001/XMLSchema#int').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2001/XMLSchema#integer').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2001/XMLSchema#long').
holds('_subClassOf_','http://www.w3.org/2001/XMLSchema#short','http://www.w3.org/2001/XMLSchema#short').
