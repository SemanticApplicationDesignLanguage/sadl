:- rdf_load('shape-rules.owl').
:- consult('shape-rules.pl').
:- rdf_load('shapes-rules-alt.owl').
:- consult('shapes-rules-alt.pl').
