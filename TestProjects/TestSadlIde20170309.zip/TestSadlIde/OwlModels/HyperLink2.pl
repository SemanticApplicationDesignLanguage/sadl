:- rdf_load('HyperLink1.owl').
:- consult('HyperLink1.pl').
