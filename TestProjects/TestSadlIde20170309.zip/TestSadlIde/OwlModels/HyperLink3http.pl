:- rdf_load('HyperLink2http.owl').
:- consult('HyperLink2http.pl').
