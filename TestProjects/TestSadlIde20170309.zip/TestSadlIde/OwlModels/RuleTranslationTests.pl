holds('http://com.ge.research.sadlruletranslationtests#op2', PVd2, PVd1) :- holds('http://com.ge.research.sadlruletranslationtests#op1', PVd2, PVd1), PVd1 \== PVd2.
