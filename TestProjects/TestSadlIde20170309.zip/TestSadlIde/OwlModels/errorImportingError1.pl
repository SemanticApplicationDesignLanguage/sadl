:- rdf_load('errorDualPropertyType.owl').
:- consult('errorDualPropertyType.pl').
