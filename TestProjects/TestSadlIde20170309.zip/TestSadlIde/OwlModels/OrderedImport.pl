:- rdf_load('importA.owl').
:- consult('importA.pl').
:- rdf_load('importB.owl').
:- consult('importB.pl').
