:- module('fa00-1bd7-935b-b8d5.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/floatinruleproblem#result', PVx, true) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/floatinruleproblem#Thingy'), holds('http://sadl.imp/floatinruleproblem#intVal', PVx, PVv1), PVv1 == 1.0)).
qresult([true]) :- true.

