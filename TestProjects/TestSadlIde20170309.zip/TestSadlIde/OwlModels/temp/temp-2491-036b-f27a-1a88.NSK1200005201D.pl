:- module('2491-036b-f27a-1a88.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/tests/rules/t1ist2#dpo4', PVx, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/tests/rules/t1ist2#Thingy'), holds('http://sadl.imp/tests/rules/t1ist2#dpi1', PVx, literal(type(PV72,PV73))), atom_number(PV73,PVv0))).
qresult([true]) :- true.

