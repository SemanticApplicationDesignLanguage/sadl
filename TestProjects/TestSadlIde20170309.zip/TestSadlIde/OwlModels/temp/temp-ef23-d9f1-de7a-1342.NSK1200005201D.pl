:- module('ef23-d9f1-de7a-1342.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/errorUndefinedConceptInRule#area', PVx, PVv2) :- PVx == 'http://sadl.imp/errorUndefinedConceptInRule#MyCircle', holds('http://sadl.imp/errorUndefinedConceptInRule#radius', PVx, literal(type(PV78,PV79))), atom_number(PV79,PVv0), PVv1 is 3.1416 * PVv0, PVv2 is PVv1 * PVv0)).
qresult([true]) :- true.

