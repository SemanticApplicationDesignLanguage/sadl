:- module('6ec1-d4c6-fbfd-9aa7.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((print(PVx1, ' != ', PVx2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx1, 'http://sadl.org/TestSadlIde/ExtendedGreaterThan#Thingy'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx2, 'http://sadl.org/TestSadlIde/ExtendedGreaterThan#Thingy'), PVx1 \== PVx2)).
qresult([true]) :- true.

