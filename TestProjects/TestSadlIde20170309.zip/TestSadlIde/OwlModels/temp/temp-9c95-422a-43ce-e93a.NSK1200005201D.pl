:- module('9c95-422a-43ce-e93a.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://com.ge.research.sadl/DoubleEqualInRule#isPastel', PVx, true) :- holds('http://com.ge.research.sadl/DoubleEqualInRule#color', PVx, PVy), PVy == 'http://com.ge.research.sadl/DoubleEqualInRule#Yellow')).
qresult([true]) :- true.

