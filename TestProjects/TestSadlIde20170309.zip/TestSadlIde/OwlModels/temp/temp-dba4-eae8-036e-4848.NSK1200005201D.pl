:- module('dba4-eae8-036e-4848.NSK1200005201D',[]).
targetVar(['X']).
qresult([X]) :- current_functor(strConcat,X).

