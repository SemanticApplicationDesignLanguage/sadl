:- module('5181-e597-a2f2-eeb5.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/familyrelationships#sibling', PVz, PVy) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationships#Person'), holds('http://sadl.imp/familyrelationships#child', PVx, PVy), holds('http://sadl.imp/familyrelationships#child', PVx, PVz), PVy \== PVz)).
qresult([true]) :- true.

