:- module('05ee-03da-eb06-63b6.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/testsadlide/test#dp5', PVx, PVv3) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/testsadlide/test#Thingy'), holds('http://sadl.imp/testsadlide/test#dp1', PVx, literal(type(PV10,PV11))), atom_number(PV11,PVv0), PVv0 > 0, PVv1 is PVv0 - 1, PVv2 is .25 * PVv1, PVv3 is 10.0   PVv2)).
qresult([true]) :- true.

