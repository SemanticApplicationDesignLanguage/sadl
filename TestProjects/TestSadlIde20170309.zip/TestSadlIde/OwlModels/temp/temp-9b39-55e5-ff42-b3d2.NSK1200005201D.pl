:- module('9b39-55e5-ff42-b3d2.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/JenaBuiltin#p3', PVw, PVv2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVw, 'http://sadl.imp/JenaBuiltin#Widget'), holds('http://sadl.imp/JenaBuiltin#p1', PVw, literal(type(PV60,PV61))), atom_number(PV61,PVv0), holds('http://sadl.imp/JenaBuiltin#p2', PVw, literal(type(PV62,PV63))), atom_number(PV63,PVv1), PVv2 is PVv0 - PVv1)).
qresult([true]) :- true.

