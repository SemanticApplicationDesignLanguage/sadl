:- module('de76-0b51-d141-aedc.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/familyrelationshipsDL#cousin', PVc2, PVc1) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationshipsDL#Person'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/familyrelationshipsDL#Person'), holds('http://sadl.imp/familyrelationshipsDL#sibling', PVy, PVx), holds('http://sadl.imp/familyrelationshipsDL#child', PVx, PVc1), holds('http://sadl.imp/familyrelationshipsDL#child', PVy, PVc2), PVc1 \== PVc2)).
qresult([true]) :- true.

