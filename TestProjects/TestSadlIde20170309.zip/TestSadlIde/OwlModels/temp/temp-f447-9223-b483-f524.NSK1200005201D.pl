:- module('f447-9223-b483-f524.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://www.w3.org/2000/01/rdf-schema#comment', PVx, 'set by Rule2') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/InferComments#Thingy'), holds('http://sadl.imp/InferComments#p2', PVx, 'red'))).
qresult([true]) :- true.

