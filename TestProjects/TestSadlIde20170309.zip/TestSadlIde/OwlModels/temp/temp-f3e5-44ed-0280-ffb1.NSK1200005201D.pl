:- module('f3e5-44ed-0280-ffb1.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/familyrelationshipsDL#uncle', PVz, PVx) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationshipsDL#Man'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/familyrelationshipsDL#Person'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVz, 'http://sadl.imp/familyrelationshipsDL#Person'), holds('http://sadl.imp/familyrelationshipsDL#sibling', PVy, PVx), holds('http://sadl.imp/familyrelationshipsDL#child', PVy, PVz))).
qresult([true]) :- true.

