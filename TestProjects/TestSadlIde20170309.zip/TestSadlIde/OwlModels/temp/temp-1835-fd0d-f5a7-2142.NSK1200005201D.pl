:- module('1835-fd0d-f5a7-2142.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/testsadlide/test#dp4', PVx, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/testsadlide/test#Thingy'), holds('http://sadl.imp/testsadlide/test#dp1', PVx, PVv1), PVv1 == 0, holds('http://sadl.imp/testsadlide/test#dp2', PVx, literal(type(PV6,PV7))), atom_number(PV7,PVv0))).
qresult([true]) :- true.

