:- module('3173-e537-4421-8f0f.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://com.ge.research.sadl/DoubleEqualInRule#isPastel', PVx, true) :- holds('http://com.ge.research.sadl/DoubleEqualInRule#color', PVx, PVy), PVy == 'http://com.ge.research.sadl/DoubleEqualInRule#Yellow')).
qresult([true]) :- true.

