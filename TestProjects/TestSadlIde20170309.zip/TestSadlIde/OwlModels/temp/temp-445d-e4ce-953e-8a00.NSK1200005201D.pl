:- module('445d-e4ce-953e-8a00.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/errorUndefinedConceptInRule#area', PVx, PVv1) :- PVx == PVYourCircle, holds('http://sadl.imp/errorUndefinedConceptInRule#radius', PVx, literal(type(PV80,PV81))), atom_number(PV81,PVv0), PVv0 is 3.1416 * PVv0, PVv1 is PVv0 * PVv0)).
qresult([true]) :- true.

