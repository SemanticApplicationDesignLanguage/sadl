:- module('8a68-e167-06df-ca6e.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/familyrelationships#uncle', PVz, PVx) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationships#Man'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/familyrelationships#Person'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVz, 'http://sadl.imp/familyrelationships#Person'), holds('http://sadl.imp/familyrelationships#sibling', PVy, PVx), holds('http://sadl.imp/familyrelationships#child', PVy, PVz))).
qresult([true]) :- true.

