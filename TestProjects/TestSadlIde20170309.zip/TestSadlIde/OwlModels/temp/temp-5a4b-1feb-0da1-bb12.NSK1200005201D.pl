:- module('5a4b-1feb-0da1-bb12.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((print(PVx, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'This works!') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadl/Bug3453776#Thingy'))).
qresult([true]) :- true.

