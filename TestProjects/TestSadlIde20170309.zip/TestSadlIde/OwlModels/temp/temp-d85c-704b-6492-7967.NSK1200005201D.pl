:- module('d85c-704b-6492-7967.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://com.ge.research.sadlnegation#isNotBlue', PVx, true) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadlnegation#Thingy'), noValue(PVx, 'http://com.ge.research.sadlnegation#color', 'http://com.ge.research.sadlnegation#Blue'))).
qresult([true]) :- true.

