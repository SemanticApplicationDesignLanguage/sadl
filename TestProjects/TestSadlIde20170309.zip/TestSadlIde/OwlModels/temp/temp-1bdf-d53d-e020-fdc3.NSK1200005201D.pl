:- module('1bdf-d53d-e020-fdc3.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.org/TEST_SADL/Test2#foo', PVx, true) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TEST_SADL/Test2#Person'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVs, 'http://sadl.org/TEST_SADL/Test2#USCitizen'), holds('http://sadl.org/TEST_SADL/Test2#spouse', PVx, PVs), holds('http://sadl.org/TEST_SADL/Test2#age', PVs, literal(type(PV96,PV97))), atom_number(PV97,PVv0), PVv0 < 40, PVv0 > 20)).
qresult([true]) :- true.

