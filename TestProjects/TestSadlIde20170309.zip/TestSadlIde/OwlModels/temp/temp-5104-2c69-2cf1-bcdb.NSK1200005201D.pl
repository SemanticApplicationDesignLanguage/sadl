:- module('5104-2c69-2cf1-bcdb.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/tests/rules/t1ist2#dpo3', PVx, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/tests/rules/t1ist2#Thingy'), holds('http://sadl.imp/tests/rules/t1ist2#dpi1', PVx, literal(type(PV70,PV71))), atom_number(PV71,PVv0))).
qresult([true]) :- true.

