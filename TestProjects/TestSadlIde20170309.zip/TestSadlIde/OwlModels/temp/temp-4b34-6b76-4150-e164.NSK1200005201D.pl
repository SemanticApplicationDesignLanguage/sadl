:- module('4b34-6b76-4150-e164.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/shapes-rules-alt#areaSqIn', PVs, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVs, 'http://sadl.imp/shapes_top#Shape'), holds('http://sadl.imp/shapes_top#unitOfMeasure', PVs, 'http://sadl.imp/shapes_top#Foot'), holds('http://sadl.imp/shapes_top#area', PVs, literal(type(PV22,PV23))), atom_number(PV23,PVaf), PVv0 is PVaf * 144)).
qresult([true]) :- true.

