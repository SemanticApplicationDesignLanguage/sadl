:- module('14fc-04f9-44df-7416.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.org/TestSadlIde/Trig#cos', PVx, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TestSadlIde/Trig#Angle'), holds('http://sadl.org/TestSadlIde/Trig#angle', PVx, literal(type(PV28,PV29))), atom_number(PV29,PVy), PVv0 is cos(PVy, PVv0), PVv1 is sin(PVy, PVv1), PVv2 is tan(PVy, PVv2), PVv3 is cos(PVy, PVv3), PVv4 is acos(PVv3, PVv4), PVv5 is sin(PVy, PVv5), PVv6 is asin(PVv5, PVv6), PVv7 is tan(PVy, PVv7), PVv8 is atan(PVv7, PVv8))).
qresult([true]) :- true.

