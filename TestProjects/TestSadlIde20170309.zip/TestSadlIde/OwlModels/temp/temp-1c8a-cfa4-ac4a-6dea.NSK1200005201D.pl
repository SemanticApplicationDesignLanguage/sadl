:- module('1c8a-cfa4-ac4a-6dea.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((print('Name of ', PVy, ' contains EM') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TestSadlIde/RegexExample#Thingy'), holds('http://sadl.org/TestSadlIde/RegexExample#name', PVx, literal(type(PV100,PV101))),PVy), regex(PVy, 'EM.*'))).
qresult([true]) :- true.

