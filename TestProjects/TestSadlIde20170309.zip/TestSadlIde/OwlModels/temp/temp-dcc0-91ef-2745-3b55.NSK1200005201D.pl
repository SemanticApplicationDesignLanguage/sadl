:- module('dcc0-91ef-2745-3b55.NSK1200005201D',[]).
targetVar(['X']).
qresult([X]) :- current_functor(oneOf,X).

