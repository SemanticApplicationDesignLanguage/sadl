:- module('af22-71f6-8737-6455.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((print(PVx, 'http://com.ge.research.sadl/Bug3453776#aProp', PVy) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadl/Bug3453776#Thingy'), holds('http://com.ge.research.sadl/Bug3453776#aProp', PVx, literal(type(PV54,PV55))),PVy))).
qresult([true]) :- true.

