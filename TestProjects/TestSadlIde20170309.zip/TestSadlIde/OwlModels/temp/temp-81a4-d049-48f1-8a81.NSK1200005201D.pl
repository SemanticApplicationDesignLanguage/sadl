:- module('81a4-d049-48f1-8a81.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/familyrelationshipsDL#cousin', PVc2, PVc1) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationshipsDL#Person'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/familyrelationshipsDL#Person'), holds('http://sadl.imp/familyrelationshipsDL#sibling', PVy, PVx), holds('http://sadl.imp/familyrelationshipsDL#child', PVx, PVc1), holds('http://sadl.imp/familyrelationshipsDL#child', PVy, PVc2), PVc1 \== PVc2)).
qresult([true]) :- true.

