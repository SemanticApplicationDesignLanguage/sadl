:- module('e693-0218-7d56-aebc.NSK1200005201D',[]).
targetVar(['X']).
qresult([X]) :- current_functor(regex,X).

