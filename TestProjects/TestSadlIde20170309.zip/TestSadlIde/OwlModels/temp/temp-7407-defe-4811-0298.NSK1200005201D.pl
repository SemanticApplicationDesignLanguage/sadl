:- module('7407-defe-4811-0298.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/familyrelationships#aunt', PVz, PVx) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationships#Woman'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/familyrelationships#Person'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVz, 'http://sadl.imp/familyrelationships#Person'), holds('http://sadl.imp/familyrelationships#sibling', PVy, PVx), holds('http://sadl.imp/familyrelationships#child', PVy, PVz))).
qresult([true]) :- true.

