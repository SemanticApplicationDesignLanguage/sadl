:- module('1dc2-09fc-43cb-d718.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((print('hi') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadl/fm234573#D'), holds('http://com.ge.research.sadl/fm234573#p1', PVx, literal(type(PV48,PV49))), atom_number(PV49,PVy))).
qresult([true]) :- true.

