:- module('9a22-183f-f98a-5276.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/shapes_top#area', PVx, PVv2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/shapes_specific#Rectangle'), holds('http://sadl.imp/shapes_specific#height', PVx, literal(type(PV14,PV15))), atom_number(PV15,PVv0), holds('http://sadl.imp/shapes_specific#width', PVx, literal(type(PV16,PV17))), atom_number(PV17,PVv1), PVv2 is PVv0 * PVv1)).
qresult([true]) :- true.

