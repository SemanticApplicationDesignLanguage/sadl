:- module('e9d0-3452-97f0-97c4.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/familyrelationshipsDL#ancestor', PVx, PVy) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationshipsDL#Person'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/familyrelationshipsDL#Person'), holds('http://sadl.imp/familyrelationshipsDL#child', PVy, PVx))).
qresult([true]) :- true.

