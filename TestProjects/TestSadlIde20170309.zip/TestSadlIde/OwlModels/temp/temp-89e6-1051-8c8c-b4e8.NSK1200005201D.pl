:- module('89e6-1051-8c8c-b4e8.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/IsNotOfTypeRule#passed', PVx, true) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/IsNotOfTypeRule#Exam'), \ holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/IsNotOfTypeRule#NotAnExam'))).
qresult([true]) :- true.

