:- module('64d7-d70b-d19d-c48a.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://com.ge.research.sadl/RuleLiterals#dprop', PVx, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadl/RuleLiterals#Thingy'), PVv0 is 6.0 / 12.0, PVv1 is 6 / 12)).
qresult([true]) :- true.

