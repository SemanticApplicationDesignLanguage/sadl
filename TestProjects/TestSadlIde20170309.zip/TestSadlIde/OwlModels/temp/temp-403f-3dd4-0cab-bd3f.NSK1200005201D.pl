:- module('403f-3dd4-0cab-bd3f.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationships#Man') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationships#Person'), holds('http://sadl.imp/familyrelationships#gender', PVx, 'http://sadl.imp/familyrelationships#Male'))).
qresult([true]) :- true.

