:- module('1784-741d-44a9-6ba1.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.org/TestSadlIde/DateMinMax#openingEvent', PVc, PVoe) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVc, 'http://sadl.org/TestSadlIde/DateMinMax#Circus'), list(PVc, 'http://sadl.org/TestSadlIde/DateMinMax#event', PVe, PVe, 'http://sadl.org/TestSadlIde/DateMinMax#when', PVeventList), PVoet is min(PVeventList, PVoet), holds('http://sadl.org/TestSadlIde/DateMinMax#when', PVoe, literal(type(PV40,PV41))),PVoet))).
qresult([true]) :- true.

