:- module('7152-8954-b821-ba87.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/PeircesNessesMotherhoodTwo#child', PVm, PVc) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/PeircesNessesMotherhoodTwo#Motherhood'), holds('http://sadl.imp/PeircesNessesMotherhoodTwo#motherIn', PVx, PVm), holds('http://sadl.imp/PeircesNessesMotherhoodTwo#childIn', PVx, PVc))).
qresult([true]) :- true.

