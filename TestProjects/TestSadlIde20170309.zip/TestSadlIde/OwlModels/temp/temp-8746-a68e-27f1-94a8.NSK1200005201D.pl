:- module('8746-a68e-27f1-94a8.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/min#dblVal', PVx, PVv2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/min#Thingy'), PVv0 is min(-1, min(1, 3)), PVv1 is min(2.0, min(-1.0, -2.0)), PVv2 is min(-1.0, min(0, 1)))).
qresult([true]) :- true.

