:- module('d7f7-f2e7-fb7d-387f.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/shapes_top#area', PVx, PVv2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/shapes_specific#Circle'), holds('http://sadl.imp/shapes_specific#radius', PVx, literal(type(PV12,PV13))), atom_number(PV13,PVv0), PVv1 is PVv0 ** 2, PVv2 is PVv1 * 3.14159)).
qresult([true]) :- true.

