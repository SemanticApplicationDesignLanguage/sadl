:- module('ba59-4b98-c9e4-0715.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/SubtractDates#day_before', PVe, PVv1) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVe, 'http://sadl.imp/SubtractDates#Computer'), holds('http://sadl.imp/SubtractDates#purchase_date', PVe, literal(type(PV68,PV69))),PVv0), subtractDates(PVv0, -1, 'D', PVv1))).
qresult([true]) :- true.

