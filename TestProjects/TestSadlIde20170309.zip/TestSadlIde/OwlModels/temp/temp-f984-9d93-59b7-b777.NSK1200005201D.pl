:- module('f984-9d93-59b7-b777.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://www.w3.org/2000/01/rdf-schema#comment', PVx, 'You are an A!') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/DuplicateImportPrefixLevel3#A'))).
qresult([true]) :- true.

