:- module('00ee-a191-1587-7774.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/familyrelationshipsDL#aunt', PVz, PVx) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationshipsDL#Woman'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/familyrelationshipsDL#Person'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVz, 'http://sadl.imp/familyrelationshipsDL#Person'), holds('http://sadl.imp/familyrelationshipsDL#sibling', PVy, PVx), holds('http://sadl.imp/familyrelationshipsDL#child', PVy, PVz))).
qresult([true]) :- true.

