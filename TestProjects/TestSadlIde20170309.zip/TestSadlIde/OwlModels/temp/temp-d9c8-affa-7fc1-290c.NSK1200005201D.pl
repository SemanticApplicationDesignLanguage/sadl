:- module('d9c8-affa-7fc1-290c.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((print(PVx, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'This works!') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadl/Bug3453776#Thingy'))).
qresult([true]) :- true.

