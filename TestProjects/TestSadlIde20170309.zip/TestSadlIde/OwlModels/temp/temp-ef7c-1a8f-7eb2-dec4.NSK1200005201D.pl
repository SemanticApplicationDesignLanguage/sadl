:- module('ef7c-1a8f-7eb2-dec4.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://com.ge.research.sadl/rulerefbeforedef#likes', PVy, 'cold weather in the winter') :- holds('http://com.ge.research.sadl/rulerefbeforedef#location', PVx, PVv0), holds('http://com.ge.research.sadl/rulerefbeforedef#latitude', PVv0, literal(type(PV0,PV1))), atom_number(PV1,PVv2), holds('http://com.ge.research.sadl/rulerefbeforedef#latitude', 'Philadelphia', literal(type(PV2,PV3))), atom_number(PV3,PVv1), PVv2 > PVv1, holds('http://com.ge.research.sadl/rulerefbeforedef#child', PVx, PVy))).
qresult([true]) :- true.

