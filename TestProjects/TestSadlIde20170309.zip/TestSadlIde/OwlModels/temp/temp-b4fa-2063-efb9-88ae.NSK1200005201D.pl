:- module('b4fa-2063-efb9-88ae.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://com.ge.research.sadlgeorgeandmartha#likes', PVy, 'cold weather in the winter') :- holds('http://com.ge.research.sadlgeorgeandmartha#location', PVx, PVv0), holds('http://com.ge.research.sadlgeorgeandmartha#latitude', PVv0, literal(type(PV50,PV51))), atom_number(PV51,PVv2), holds('http://com.ge.research.sadlgeorgeandmartha#latitude', 'http://com.ge.research.sadlgeorgeandmartha#Philadelphia', literal(type(PV52,PV53))), atom_number(PV53,PVv1), PVv2 > PVv1, holds('http://com.ge.research.sadlgeorgeandmartha#child', PVx, PVy))).
qresult([true]) :- true.

