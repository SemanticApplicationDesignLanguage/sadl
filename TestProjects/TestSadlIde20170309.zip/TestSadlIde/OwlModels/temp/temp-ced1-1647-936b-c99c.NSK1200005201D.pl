:- module('ced1-1647-936b-c99c.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.org/TestSadlIde/AssignmentOfBoolean#bp', PVx, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TestSadlIde/AssignmentOfBoolean#Thingy'), noValue(PVx, 'http://sadl.org/TestSadlIde/AssignmentOfBoolean#op', 'http://sadl.org/TestSadlIde/AssignmentOfBoolean#Small', PVv0))).
qresult([true]) :- true.

