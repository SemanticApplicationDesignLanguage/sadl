:- module('8173-d13e-2957-2186.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.org/TestSadlIde/DateMinMax#closingEvent', PVc, PVce) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVc, 'http://sadl.org/TestSadlIde/DateMinMax#Circus'), list(PVc, 'http://sadl.org/TestSadlIde/DateMinMax#event', PVe, PVe, 'http://sadl.org/TestSadlIde/DateMinMax#when', PVeventList), PVcet is max(PVeventList, PVcet), holds('http://sadl.org/TestSadlIde/DateMinMax#when', PVce, literal(type(PV42,PV43))),PVcet))).
qresult([true]) :- true.

