:- module('f68e-d9d7-d706-c27e.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/SubtractDates#lag', PVe, PVv2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVe, 'http://sadl.imp/SubtractDates#Computer'), holds('http://sadl.imp/SubtractDates#purchase_date', PVe, literal(type(PV64,PV65))),PVv0), holds('http://sadl.imp/SubtractDates#current_date', PVe, literal(type(PV66,PV67))),PVv1), subtractDates(PVv0, PVv1, 'Mo', PVv2))).
qresult([true]) :- true.

