:- module('39a2-758d-23c0-67a8.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://com.ge.research.sadl/NotEqualRule2#connectedTo', PVy, PVz) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadl/NotEqualRule2#Thingy'), holds('http://com.ge.research.sadl/NotEqualRule2#connectedTo', PVx, PVy), holds('http://com.ge.research.sadl/NotEqualRule2#connectedTo', PVx, PVz), PVz \== PVy)).
qresult([true]) :- true.

