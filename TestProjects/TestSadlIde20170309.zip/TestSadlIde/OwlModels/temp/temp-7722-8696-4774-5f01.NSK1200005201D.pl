:- module('7722-8696-4774-5f01.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.org/TestSadlIde/WhatIsIs#dp', PVt, PVz) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVt, 'http://sadl.org/TestSadlIde/WhatIsIs#Thingy'), 3 is PVx, 5 is PVy, PVz is PVx   PVy, PVz == 8)).
qresult([true]) :- true.

