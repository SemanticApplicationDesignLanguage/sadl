:- module('509c-87d3-f558-0946.NSK1200005201D',[]).
targetVar(['_DummyVar']).
qresult([true]) :- true.

