:- module('1c49-5988-6948-6fec.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((print(PVx1, ' != ', PVx2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx1, 'http://sadl.org/TestSadlIde/ExtendedGreaterThan#Thingy'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx2, 'http://sadl.org/TestSadlIde/ExtendedGreaterThan#Thingy'), PVx1 \== PVx2)).
qresult([true]) :- true.

