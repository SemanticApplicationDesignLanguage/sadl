:- module('fd47-1c16-24d0-85e1.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://com.ge.research.sadl/RuleWarnings#objproperty', 'http://com.ge.research.sadl/RuleWarnings#InstRC1', PVvar2) :- holds(PVvar1, 'http://com.ge.research.sadl/RuleWarnings#objproperty', PVvar2), holds('http://com.ge.research.sadl/RuleWarnings#objproperty', PVvar1, PVv0), \  PVv1)).
qresult([true]) :- true.

