:- module('d420-94b3-69bc-ef9a.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/testsadlide/error1#dp4', PVx, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/testsadlide/error1#Thingy'), holds('http://sadl.imp/testsadlide/error1#dp1', PVx, PVv1), PVv1 == 0, holds('http://sadl.imp/testsadlide/error1#dp2', PVx, literal(type(PV108,PV109))), atom_number(PV109,PVv0))).
qresult([true]) :- true.

