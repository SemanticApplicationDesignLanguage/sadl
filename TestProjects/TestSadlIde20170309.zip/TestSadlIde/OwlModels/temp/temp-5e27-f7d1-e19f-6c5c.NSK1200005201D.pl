:- module('5e27-f7d1-e19f-6c5c.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((print(PVx, ' is a good pet.') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TestSadlIde/UnionClassInRule#Mammal'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, PVt), oneOf(PVt, 'http://sadl.org/TestSadlIde/UnionClassInRule#Dog', 'http://sadl.org/TestSadlIde/UnionClassInRule#Cat'))).
qresult([true]) :- true.

