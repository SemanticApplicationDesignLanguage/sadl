:- module('b044-061e-ca7d-6cb2.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/abs#intVal', PVx, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/abs#Thingy'), PVv0 is abs(-1, PVv0), PVv1 is abs(-1.0, PVv1), PVv2 is abs(-1.0, PVv2))).
qresult([true]) :- true.

