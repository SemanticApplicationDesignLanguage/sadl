:- module('969d-6678-97f8-0284.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/familyrelationships#ancestor', PVx, PVy) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationships#Person'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/familyrelationships#Person'), holds('http://sadl.imp/familyrelationships#child', PVy, PVx))).
qresult([true]) :- true.

