:- module('7407-a5fa-9fff-7956.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((print(PVx, ' has area ', PVy) :- holds('http://sadl.imp/shapes_top#area', PVx, literal(type(PV18,PV19))), atom_number(PV19,PVy))).
qresult([true]) :- true.

