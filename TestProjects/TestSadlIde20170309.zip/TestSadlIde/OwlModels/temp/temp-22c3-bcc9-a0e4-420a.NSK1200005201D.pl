:- module('22c3-bcc9-a0e4-420a.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/PeircesNesses#mother', PVc, PVm) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/PeircesNesses#BirthEvent'), holds('http://sadl.imp/PeircesNesses#motherIn', PVx, PVm), holds('http://sadl.imp/PeircesNesses#childIn', PVx, PVc))).
qresult([true]) :- true.

