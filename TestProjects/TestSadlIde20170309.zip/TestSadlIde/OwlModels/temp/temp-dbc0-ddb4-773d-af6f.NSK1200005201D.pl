:- module('dbc0-ddb4-773d-af6f.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((print(PVx, ' is not a Dog') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadl/NotClassRule#Mammal'), noValue(PVx, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://com.ge.research.sadl/NotClassRule#Dog'))).
qresult([true]) :- true.

