:- module('1691-f7da-4163-d0d0.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://com.ge.research.sadlnewlineinstrconcat#description', PVx, PVe) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadlnewlineinstrconcat#Thingy'), strConcat('First line\\\\n', 'Second line: x=', PVx, '\\\\n', 'Third line\\\\n', PVe))).
qresult([true]) :- true.

