:- module('959c-a2af-8b1f-cb32.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/RDFSTransitiveClosureWithRule#ruleFired', PVx, true) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/RDFSTransitiveClosureWithRule#Thingy'))).
qresult([true]) :- true.

