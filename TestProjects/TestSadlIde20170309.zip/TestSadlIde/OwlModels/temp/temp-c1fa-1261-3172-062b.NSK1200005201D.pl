:- module('c1fa-1261-3172-062b.NSK1200005201D',[]).
targetVar(['X']).
qresult([X]) :- current_functor(subtractDates,X).

