:- module('c22a-8cdd-c54e-6a9e.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/RuleCommentIsComment#color', PVx, PVv3) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/RuleCommentIsComment#Thingy'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/RuleCommentIsComment#Thingy'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVz, 'http://sadl.imp/RuleCommentIsComment#Thingy'), holds('http://sadl.imp/RuleCommentIsComment#madeOf', PVx, PVv0), holds('http://sadl.imp/RuleCommentIsComment#madeOf', PVy, PVv1), PVv0 == PVv1, holds('http://www.w3.org/2000/01/rdf-schema#comment', PVy, PVv2), holds('http://sadl.imp/RuleCommentIsComment#color', PVy, literal(type(PV26,PV27))),PVv3))).
qresult([true]) :- true.

