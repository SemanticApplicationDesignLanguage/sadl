:- module('1672-2802-2119-871c.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/NotEqualRule#action', PVx, 'http://sadl.imp/NotEqualRule#Stop') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/NotEqualRule#Vehicle'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/NotEqualRule#TrafficLight'), holds('http://sadl.imp/NotEqualRule#approaching', PVy, PVx), holds('http://sadl.imp/NotEqualRule#color', PVy, PVc), PVc \== 'http://sadl.imp/NotEqualRule#Green')).
qresult([true]) :- true.

