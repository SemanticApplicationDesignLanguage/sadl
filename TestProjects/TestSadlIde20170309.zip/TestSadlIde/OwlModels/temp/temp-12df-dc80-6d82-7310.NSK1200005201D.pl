:- module('12df-dc80-6d82-7310.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/errorUndefinedConceptInRule#area', PVx, PVv2) :- PVx == 'http://sadl.imp/errorUndefinedConceptInRule#MyCircle', holds('http://sadl.imp/errorUndefinedConceptInRule#radius', PVx, literal(type(PV78,PV79))), atom_number(PV79,PVv0), PVv1 is 3.1416 * PVv0, PVv2 is PVv1 * PVv0)).
qresult([true]) :- true.

