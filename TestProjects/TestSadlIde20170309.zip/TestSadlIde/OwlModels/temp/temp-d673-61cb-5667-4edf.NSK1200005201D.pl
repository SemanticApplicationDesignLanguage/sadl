:- module('d673-61cb-5667-4edf.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/TransitiveClosureOnClasses#Dog') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/TransitiveClosureOnClasses#Pet'), PVx == 'http://sadl.imp/TransitiveClosureOnClasses#Spot')).
qresult([true]) :- true.

