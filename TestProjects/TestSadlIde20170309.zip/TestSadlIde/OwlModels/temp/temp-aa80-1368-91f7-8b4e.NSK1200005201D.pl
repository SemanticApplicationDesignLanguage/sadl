:- module('aa80-1368-91f7-8b4e.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/familyrelationshipsDL#sibling', PVz, PVy) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationshipsDL#Person'), holds('http://sadl.imp/familyrelationshipsDL#child', PVx, PVy), holds('http://sadl.imp/familyrelationshipsDL#child', PVx, PVz), PVy \== PVz)).
qresult([true]) :- true.

