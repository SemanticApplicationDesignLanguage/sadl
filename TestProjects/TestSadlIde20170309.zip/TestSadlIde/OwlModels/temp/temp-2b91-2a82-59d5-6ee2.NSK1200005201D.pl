:- module('2b91-2a82-59d5-6ee2.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.org/TestSadlIde/RegexExample#rest', PVx, PVs2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TestSadlIde/RegexExample#Thingy'), holds('http://sadl.org/TestSadlIde/RegexExample#name', PVx, literal(type(PV102,PV103))),PVy), regex(PVy, 'EM(.)', PVs1, PVs2))).
qresult([true]) :- true.

