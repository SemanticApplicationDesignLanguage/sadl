:- module('4774-adba-c8a9-9196.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://com.ge.research.sadlnegation#isRed', PVx, false) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadlnegation#Thingy'), noValue(PVx, 'http://com.ge.research.sadlnegation#color', 'http://com.ge.research.sadlnegation#Red'))).
qresult([true]) :- true.

