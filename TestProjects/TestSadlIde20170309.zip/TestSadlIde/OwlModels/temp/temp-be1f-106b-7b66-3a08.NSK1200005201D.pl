:- module('be1f-106b-7b66-3a08.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/InferComments#p3', PVx, 'green') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/InferComments#Thingy'), holds('http://sadl.imp/InferComments#p2', PVx, 'red'))).
qresult([true]) :- true.

