:- module('4fb9-ee08-eef6-cdac.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/PeircesNessesMotherhoodTwo#child', PVm, PVc) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/PeircesNessesMotherhoodTwo#Motherhood'), holds('http://sadl.imp/PeircesNessesMotherhoodTwo#motherIn', PVx, PVm), holds('http://sadl.imp/PeircesNessesMotherhoodTwo#childIn', PVx, PVc))).
qresult([true]) :- true.

