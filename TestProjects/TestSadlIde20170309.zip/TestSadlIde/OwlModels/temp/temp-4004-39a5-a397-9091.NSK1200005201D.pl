:- module('4004-39a5-a397-9091.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/PeircesNesses#child', PVm, PVc) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/PeircesNesses#BirthEvent'), holds('http://sadl.imp/PeircesNesses#motherIn', PVx, PVm), holds('http://sadl.imp/PeircesNesses#childIn', PVx, PVc))).
qresult([true]) :- true.

