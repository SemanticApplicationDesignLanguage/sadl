:- module('3309-74a1-3f73-7e38.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.org/TestSadlIde/RuleWithVariablePredicate#onlyDP', PVx, false) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TestSadlIde/RuleWithVariablePredicate#Thingy'), holds(PVp, PVx, PVv), PVv == 'hello world')).
qresult([true]) :- true.

