:- module('2641-934d-1984-3b76.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.org/TestSadlIde/Trig#tan', PVx, PVv2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TestSadlIde/Trig#Angle'), holds('http://sadl.org/TestSadlIde/Trig#angle', PVx, literal(type(PV32,PV33))), atom_number(PV33,PVy), PVv0 is cos(PVy, PVv0), PVv1 is sin(PVy, PVv1), PVv2 is tan(PVy, PVv2), PVv3 is cos(PVy, PVv3), PVv4 is acos(PVv3, PVv4), PVv5 is sin(PVy, PVv5), PVv6 is asin(PVv5, PVv6), PVv7 is tan(PVy, PVv7), PVv8 is atan(PVv7, PVv8))).
qresult([true]) :- true.

