:- module('74b2-e9f6-6d1d-6f2a.NSK1200005201D',[]).
targetVar(['X']).
qresult([X]) :- current_functor(print,X).

