:- module('14d5-505d-f64f-6bb5.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((print(PVx, ' has area ', PVy) :- holds('http://sadl.imp/shapes_top#area', PVx, literal(type(PV18,PV19))), atom_number(PV19,PVy))).
qresult([true]) :- true.

