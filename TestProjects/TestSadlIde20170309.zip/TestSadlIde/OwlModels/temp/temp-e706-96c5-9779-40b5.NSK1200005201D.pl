:- module('e706-96c5-9779-40b5.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/SubtractDates#lag', PVe, PVv2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVe, 'http://sadl.imp/SubtractDates#Computer'), holds('http://sadl.imp/SubtractDates#purchase_date', PVe, literal(type(PV64,PV65))),PVv0), holds('http://sadl.imp/SubtractDates#current_date', PVe, literal(type(PV66,PV67))),PVv1), subtractDates(PVv0, PVv1, 'Mo', PVv2))).
qresult([true]) :- true.

