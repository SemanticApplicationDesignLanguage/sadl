:- module('dbde-9cdf-085c-9282.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((print(PVe) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadlnewlineinstrconcat#Thingy'), strConcat('First line\\\\n', 'Second line: x=', PVx, '\\\\n', 'Third line\\\\n', PVe))).
qresult([true]) :- true.

