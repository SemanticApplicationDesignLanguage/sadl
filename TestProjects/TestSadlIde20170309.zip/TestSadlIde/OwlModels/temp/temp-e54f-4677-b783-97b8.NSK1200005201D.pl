:- module('e54f-4677-b783-97b8.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((print(PVx, ' is not a Dog') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadl/NotClassRule#Mammal'), noValue(PVx, 'http://www.w3.org/1999/02/22-rdf-syntax-ns#type', 'http://com.ge.research.sadl/NotClassRule#Dog'))).
qresult([true]) :- true.

