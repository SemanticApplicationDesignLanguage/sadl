:- module('3963-ec42-1b10-3787.NSK1200005201D',[]).
targetVar(['X']).
qresult([X]) :- current_functor(list,X).

