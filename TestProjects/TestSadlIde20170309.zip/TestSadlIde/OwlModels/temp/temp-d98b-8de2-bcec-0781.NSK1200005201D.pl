:- module('d98b-8de2-bcec-0781.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/familyrelationships#cousin', PVc2, PVc1) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationships#Person'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/familyrelationships#Person'), holds('http://sadl.imp/familyrelationships#sibling', PVy, PVx), holds('http://sadl.imp/familyrelationships#child', PVx, PVc1), holds('http://sadl.imp/familyrelationships#child', PVy, PVc2), PVc1 \== PVc2)).
qresult([true]) :- true.

