:- module('82b4-059c-9fc8-5239.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationships#Woman') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationships#Person'), holds('http://sadl.imp/familyrelationships#gender', PVx, 'http://sadl.imp/familyrelationships#Female'))).
qresult([true]) :- true.

