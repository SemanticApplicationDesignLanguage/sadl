:- module('77df-e4cd-f5f8-f1e9.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/PropOfPropOf#bill', PVm, PVv7) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVm, 'http://sadl.imp/PropOfPropOf#Meal'), holds('http://sadl.imp/PropOfPropOf#appetizer', PVm, PVv0), holds('http://sadl.imp/PropOfPropOf#price', PVv0, literal(type(PV110,PV111))), atom_number(PV111,PVv1), holds('http://sadl.imp/PropOfPropOf#entree', PVm, PVv2), holds('http://sadl.imp/PropOfPropOf#price', PVv2, literal(type(PV112,PV113))), atom_number(PV113,PVv3), PVv4 is PVv1   PVv3, holds('http://sadl.imp/PropOfPropOf#desert', PVm, PVv5), holds('http://sadl.imp/PropOfPropOf#price', PVv5, literal(type(PV114,PV115))), atom_number(PV115,PVv6), PVv7 is PVv4   PVv6)).
qresult([true]) :- true.

