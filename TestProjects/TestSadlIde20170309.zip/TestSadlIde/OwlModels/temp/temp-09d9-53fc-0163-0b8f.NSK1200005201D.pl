:- module('09d9-53fc-0163-0b8f.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((print('Name of ', PVy, ' contains EM') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TestSadlIde/RegexExample#Thingy'), holds('http://sadl.org/TestSadlIde/RegexExample#name', PVx, literal(type(PV100,PV101))),PVy), regex(PVy, 'EM.*'))).
qresult([true]) :- true.

