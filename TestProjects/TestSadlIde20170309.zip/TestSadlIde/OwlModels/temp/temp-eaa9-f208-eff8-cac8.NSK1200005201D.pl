:- module('eaa9-f208-eff8-cac8.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://com.ge.research.sadlnewlineinstrconcat#description', PVx, PVe) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadlnewlineinstrconcat#Thingy'), strConcat('First line\\\\n', 'Second line: x=', PVx, '\\\\n', 'Third line\\\\n', PVe))).
qresult([true]) :- true.

