:- module('61b4-32ef-1884-af41.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((print(PVx, 'http://com.ge.research.sadl/Bug3453776#aProp', PVy) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadl/Bug3453776#Thingy'), holds('http://com.ge.research.sadl/Bug3453776#aProp', PVx, literal(type(PV54,PV55))),PVy))).
qresult([true]) :- true.

