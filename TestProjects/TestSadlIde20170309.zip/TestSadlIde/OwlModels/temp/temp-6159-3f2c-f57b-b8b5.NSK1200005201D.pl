:- module('6159-3f2c-f57b-b8b5.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://com.ge.research.sadl/RuleLiterals#dprop2', PVx, PVv1) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadl/RuleLiterals#Thingy'), PVv0 is 6.0 / 12.0, PVv1 is 6 / 12)).
qresult([true]) :- true.

