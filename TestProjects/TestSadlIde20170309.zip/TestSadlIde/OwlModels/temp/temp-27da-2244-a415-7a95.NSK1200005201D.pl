:- module('27da-2244-a415-7a95.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.org/TestSadlIde/RuleAnnotations#area', PVx, PVv2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TestSadlIde/RuleAnnotations#Rectangle'), holds('http://sadl.org/TestSadlIde/RuleAnnotations#height', PVx, literal(type(PV104,PV105))), atom_number(PV105,PVv0), holds('http://sadl.org/TestSadlIde/RuleAnnotations#width', PVx, literal(type(PV106,PV107))), atom_number(PV107,PVv1), PVv2 is PVv0 * PVv1)).
qresult([true]) :- true.

