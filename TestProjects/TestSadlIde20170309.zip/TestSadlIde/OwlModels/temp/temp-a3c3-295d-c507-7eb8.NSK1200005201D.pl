:- module('a3c3-295d-c507-7eb8.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/JenaBuiltin#p3', PVw, PVv2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVw, 'http://sadl.imp/JenaBuiltin#Widget'), holds('http://sadl.imp/JenaBuiltin#p1', PVw, literal(type(PV60,PV61))), atom_number(PV61,PVv0), holds('http://sadl.imp/JenaBuiltin#p2', PVw, literal(type(PV62,PV63))), atom_number(PV63,PVv1), PVv2 is PVv0 - PVv1)).
qresult([true]) :- true.

