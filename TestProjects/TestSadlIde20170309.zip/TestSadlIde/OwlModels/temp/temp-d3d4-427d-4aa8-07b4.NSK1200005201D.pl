:- module('d3d4-427d-4aa8-07b4.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/PeircesNessesMotherhoodTwo#mother', PVc, PVm) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/PeircesNessesMotherhoodTwo#Motherhood'), holds('http://sadl.imp/PeircesNessesMotherhoodTwo#motherIn', PVx, PVm), holds('http://sadl.imp/PeircesNessesMotherhoodTwo#childIn', PVx, PVc))).
qresult([true]) :- true.

