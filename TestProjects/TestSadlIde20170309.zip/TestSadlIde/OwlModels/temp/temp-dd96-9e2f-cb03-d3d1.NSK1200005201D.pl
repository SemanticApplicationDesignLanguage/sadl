:- module('dd96-9e2f-cb03-d3d1.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.org/TestSadlIde/AssignmentOfBoolean#bp', PVx, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TestSadlIde/AssignmentOfBoolean#Thingy'), noValue(PVx, 'http://sadl.org/TestSadlIde/AssignmentOfBoolean#op', 'http://sadl.org/TestSadlIde/AssignmentOfBoolean#Small', PVv0))).
qresult([true]) :- true.

