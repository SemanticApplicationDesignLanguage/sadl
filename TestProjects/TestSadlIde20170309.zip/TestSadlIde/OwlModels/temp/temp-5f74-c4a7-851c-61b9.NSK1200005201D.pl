:- module('5f74-c4a7-851c-61b9.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/testsadlide/test#dp4', PVx, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/testsadlide/test#Thingy'), holds('http://sadl.imp/testsadlide/test#dp1', PVx, literal(type(PV8,PV9))), atom_number(PV9,PVv0), PVv0 > 0)).
qresult([true]) :- true.

