:- module('89fe-46d7-ea41-81fd.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://com.ge.research.sadlnegation#isRed', PVx, false) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadlnegation#Thingy'), noValue(PVx, 'http://com.ge.research.sadlnegation#color', 'http://com.ge.research.sadlnegation#Red'))).
qresult([true]) :- true.

