:- module('a5d7-5933-e51e-03ca.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/floatinruleproblem#result', PVx, true) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/floatinruleproblem#Thingy'), holds('http://sadl.imp/floatinruleproblem#intVal', PVx, PVv1), PVv1 == 1.0)).
qresult([true]) :- true.

