:- module('6832-51b5-df92-e796.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/tests/rules/t1ist2#dpo5', PVx, PVv2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/tests/rules/t1ist2#Thingy'), holds('http://sadl.imp/tests/rules/t1ist2#dpi1', PVx, literal(type(PV74,PV75))), atom_number(PV75,PVv0), holds('http://sadl.imp/tests/rules/t1ist2#dpi2', PVx, literal(type(PV76,PV77))), atom_number(PV77,PVv1), PVv2 is PVv0   PVv1)).
qresult([true]) :- true.

