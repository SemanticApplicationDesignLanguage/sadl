:- module('0b96-5fa5-c5e6-019b.NSK1200005201D',[]).
targetVar(['X']).
qresult([X]) :- current_functor(print,X).

