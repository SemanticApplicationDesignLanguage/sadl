:- module('340d-c38b-4d15-4428.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/IsNotRule#action', PVx, 'http://sadl.imp/IsNotRule#Stop') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/IsNotRule#Vehicle'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/IsNotRule#TrafficLight'), holds('http://sadl.imp/IsNotRule#approaching', PVx, PVy), \ holds('http://sadl.imp/IsNotRule#color', PVy, 'http://sadl.imp/IsNotRule#Green'))).
qresult([true]) :- true.

