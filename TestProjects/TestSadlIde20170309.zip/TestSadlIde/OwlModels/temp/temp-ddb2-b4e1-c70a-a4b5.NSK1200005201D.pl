:- module('ddb2-b4e1-c70a-a4b5.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/tests/rules/t1ist2#dpo4', PVx, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/tests/rules/t1ist2#Thingy'), holds('http://sadl.imp/tests/rules/t1ist2#dpi1', PVx, literal(type(PV72,PV73))), atom_number(PV73,PVv0))).
qresult([true]) :- true.

