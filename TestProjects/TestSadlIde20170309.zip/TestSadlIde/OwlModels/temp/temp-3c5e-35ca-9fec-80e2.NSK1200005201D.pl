:- module('3c5e-35ca-9fec-80e2.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((print(PVe) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadlnewlineinstrconcat#Thingy'), strConcat('First line\\\\n', 'Second line: x=', PVx, '\\\\n', 'Third line\\\\n', PVe))).
qresult([true]) :- true.

