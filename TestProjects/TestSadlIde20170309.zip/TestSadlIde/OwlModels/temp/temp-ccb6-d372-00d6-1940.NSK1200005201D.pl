:- module('ccb6-d372-00d6-1940.NSK1200005201D',[]).
targetVar(['X']).
qresult([X]) :- current_functor(regex,X).

