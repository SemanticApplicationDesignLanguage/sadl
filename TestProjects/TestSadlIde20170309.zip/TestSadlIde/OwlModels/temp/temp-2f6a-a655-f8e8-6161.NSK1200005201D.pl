:- module('2f6a-a655-f8e8-6161.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.org/TestSadlIde/ExtendedGreaterThan#ok', PVx, true) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TestSadlIde/ExtendedGreaterThan#OtherThing'), holds('http://sadl.org/TestSadlIde/ExtendedGreaterThan#value', PVx, literal(type(PV56,PV57))), atom_number(PV57,PVv0), PVv0 < 1)).
qresult([true]) :- true.

