:- module('837f-9a1a-49e2-9b43.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/RDFSTransitiveClosureWithRule#ruleFired', PVx, true) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/RDFSTransitiveClosureWithRule#Thingy'))).
qresult([true]) :- true.

