:- module('4333-d530-9a37-0d36.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.org/TestSadlIde/ExtendedGreaterThan#lessThan', PVx1, PVx2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx1, 'http://sadl.org/TestSadlIde/ExtendedGreaterThan#Thingy'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx2, 'http://sadl.org/TestSadlIde/ExtendedGreaterThan#Thingy'), PVx1 < PVx2)).
qresult([true]) :- true.

