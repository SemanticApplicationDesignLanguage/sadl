:- module('7d1e-db42-97d2-3c29.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/testsadlide/test#dp4', PVx, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/testsadlide/test#Thingy'), holds('http://sadl.imp/testsadlide/test#dp1', PVx, literal(type(PV8,PV9))), atom_number(PV9,PVv0), PVv0 > 0)).
qresult([true]) :- true.

