:- module('fc5b-4341-759e-d926.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.imp/familyrelationships#ancestor', PVz, PVx) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationships#Person'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVy, 'http://sadl.imp/familyrelationships#Person'), holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVz, 'http://sadl.imp/familyrelationships#Person'), holds('http://sadl.imp/familyrelationships#ancestor', PVy, PVx), holds('http://sadl.imp/familyrelationships#ancestor', PVz, PVy))).
qresult([true]) :- true.

