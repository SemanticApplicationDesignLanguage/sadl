:- module('a6b4-0522-4090-faa2.NSK1200005201D',[]).
targetVar(['X']).
qresult([X]) :- current_functor(noValue,X).

