:- module('353b-053c-63b0-0333.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.imp/shapes-rules-alt#areaSqIn', PVs, PVv0) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVs, 'http://sadl.imp/shapes_top#Shape'), holds('http://sadl.imp/shapes_top#unitOfMeasure', PVs, 'http://sadl.imp/shapes_top#Foot'), holds('http://sadl.imp/shapes_top#area', PVs, literal(type(PV20,PV21))), atom_number(PV21,PVaf), PVv0 is PVaf * 144)).
qresult([true]) :- true.

