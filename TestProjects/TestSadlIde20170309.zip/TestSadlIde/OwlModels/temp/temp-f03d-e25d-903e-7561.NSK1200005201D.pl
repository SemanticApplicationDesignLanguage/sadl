:- module('f03d-e25d-903e-7561.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://com.ge.research.sadlruletranslationtests#op2', PVd2, PVd1) :- holds('http://com.ge.research.sadlruletranslationtests#op1', PVd2, PVd1), PVd1 \== PVd2)).
qresult([true]) :- true.

