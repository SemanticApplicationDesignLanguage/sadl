:- module('4451-8b0b-c143-1759.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((print('hi') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadl/fm234573#D'), holds('http://com.ge.research.sadl/fm234573#p1', PVx, literal(type(PV48,PV49))), atom_number(PV49,PVy))).
qresult([true]) :- true.

