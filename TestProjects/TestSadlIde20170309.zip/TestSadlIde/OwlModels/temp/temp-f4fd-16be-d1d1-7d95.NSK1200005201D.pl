:- module('f4fd-16be-d1d1-7d95.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationships#Woman') :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.imp/familyrelationships#Person'), holds('http://sadl.imp/familyrelationships#gender', PVx, 'http://sadl.imp/familyrelationships#Female'))).
qresult([true]) :- true.

