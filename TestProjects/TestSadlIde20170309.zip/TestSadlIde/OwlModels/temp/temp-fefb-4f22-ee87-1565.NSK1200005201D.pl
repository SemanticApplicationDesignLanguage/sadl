:- module('fefb-4f22-ee87-1565.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://sadl.org/TestSadlIde/RegexExample#rest', PVx, PVs2) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TestSadlIde/RegexExample#Thingy'), holds('http://sadl.org/TestSadlIde/RegexExample#name', PVx, literal(type(PV102,PV103))),PVy), regex(PVy, 'EM(.)', PVs1, PVs2))).
qresult([true]) :- true.

