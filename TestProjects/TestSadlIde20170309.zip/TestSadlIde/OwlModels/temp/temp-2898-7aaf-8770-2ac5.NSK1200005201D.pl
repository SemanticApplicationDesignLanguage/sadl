:- module('2898-7aaf-8770-2ac5.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://com.ge.research.sadlgeorgeandmarthaerr#likes', PVy, 'cold weather in the winter') :- holds('http://com.ge.research.sadlgeorgeandmarthaerr#location', PVx, PVv0), holds('http://com.ge.research.sadlgeorgeandmarthaerr#latitude', PVv0, literal(type(PV44,PV45))), atom_number(PV45,PVv2), holds('http://com.ge.research.sadlgeorgeandmarthaerr#latitude', 'Philadelphia', literal(type(PV46,PV47))), atom_number(PV47,PVv1), PVv2 > PVv1, holds('http://com.ge.research.sadlgeorgeandmarthaerr#child', PVx, PVy))).
qresult([true]) :- true.

