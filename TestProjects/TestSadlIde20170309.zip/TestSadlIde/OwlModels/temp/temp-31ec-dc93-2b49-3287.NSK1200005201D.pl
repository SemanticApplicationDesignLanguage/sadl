:- module('31ec-dc93-2b49-3287.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://com.ge.research.sadlruletranslationtests#op2', PVd2, PVd1) :- holds('http://com.ge.research.sadlruletranslationtests#op1', PVd2, PVd1), PVd1 \== PVd2)).
qresult([true]) :- true.

