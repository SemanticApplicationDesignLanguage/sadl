:- module('adc8-83b5-eb41-9219.NSK1200005201D',[]).
targetVar(['X']).
qresult([X]) :- current_functor(print,X).

