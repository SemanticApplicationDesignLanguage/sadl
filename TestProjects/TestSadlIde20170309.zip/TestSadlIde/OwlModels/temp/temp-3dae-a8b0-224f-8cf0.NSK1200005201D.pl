:- module('3dae-a8b0-224f-8cf0.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_pl_file('/E:/sadl/workspace-sadl/TestSadlIde/OwlModels/NotEqualRule2.pl').
:- load_rdf_file('/E:/sadl/workspace-sadl/TestSadlIde/OwlModels/NotEqualRule2.owl').

qresult([true]) :- true.

