:- module('78a1-9fe2-a6b1-9b68.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- retract_once((holds('http://sadl.org/TEST_SADL/Test2#foo', PVx, true) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://sadl.org/TEST_SADL/Test2#Person'), holds('http://sadl.org/TEST_SADL/Test2#spouse', PVx, PVs), holds('http://sadl.org/TEST_SADL/Test2#age', PVs, literal(type(PV94,PV95))), atom_number(PV95,PVv0), PVv0 < 40, PVv0 > 20, holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVs, 'http://sadl.org/TEST_SADL/Test2#USCitizen'))).
qresult([true]) :- true.

