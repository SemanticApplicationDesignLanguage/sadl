:- module('de19-11b5-d02c-44ec.NSK1200005201D',[]).
targetVar(['_DummyVar']).
:- load_into_db_beginning((holds('http://com.ge.research.sadl/NotEqualRule2#connectedTo', PVy, PVz) :- holds('http://www.w3.org/1999/02/22-rdf-syntax-ns#type', PVx, 'http://com.ge.research.sadl/NotEqualRule2#Thingy'), holds('http://com.ge.research.sadl/NotEqualRule2#connectedTo', PVx, PVy), holds('http://com.ge.research.sadl/NotEqualRule2#connectedTo', PVx, PVz), PVz \== PVy)).
qresult([true]) :- true.

