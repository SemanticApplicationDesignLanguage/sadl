:- rdf_load('HyperLink2.owl').
:- consult('HyperLink2.pl').
