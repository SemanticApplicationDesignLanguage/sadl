:- rdf_load('thatmodel.owl').
:- consult('thatmodel.pl').
