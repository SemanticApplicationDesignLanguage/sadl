:- rdf_load('BaseConcepts.owl').
:- consult('BaseConcepts.pl').
