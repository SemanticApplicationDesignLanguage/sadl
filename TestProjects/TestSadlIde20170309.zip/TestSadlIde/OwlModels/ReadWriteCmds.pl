:- rdf_load('shape-rules.owl').
:- consult('shape-rules.pl').
