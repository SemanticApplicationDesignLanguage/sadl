:- rdf_load('shapes-top.owl').
:- consult('shapes-top.pl').
