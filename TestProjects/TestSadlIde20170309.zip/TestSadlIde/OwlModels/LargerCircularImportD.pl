:- rdf_load('LargerCircularImportA.owl').
:- consult('LargerCircularImportA.pl').
