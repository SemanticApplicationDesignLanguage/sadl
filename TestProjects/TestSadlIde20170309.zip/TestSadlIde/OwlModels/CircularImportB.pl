:- rdf_load('CircularImportA.owl').
:- consult('CircularImportA.pl').
