:- rdf_load('DuplicateImportPrefixLevel3.owl').
:- consult('DuplicateImportPrefixLevel3.pl').
