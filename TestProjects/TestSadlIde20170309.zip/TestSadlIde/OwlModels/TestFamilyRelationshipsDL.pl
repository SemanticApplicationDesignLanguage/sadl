:- rdf_load('FamilyRelationshipsDL.owl').
:- consult('FamilyRelationshipsDL.pl').
