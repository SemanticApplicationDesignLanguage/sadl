:- rdf_load('userdefineddatatypes.owl').
:- consult('userdefineddatatypes.pl').
